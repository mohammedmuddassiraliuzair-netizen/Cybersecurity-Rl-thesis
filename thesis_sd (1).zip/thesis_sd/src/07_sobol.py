"""Stage 7: global variance-based (Sobol) sensitivity analysis of the calibrated SD model.

Sobol indices (Saltelli et al. 2010 estimators, SALib): first-order S1 = share of output variance
explained by a parameter alone; total-order ST = share including all its interactions.
Each sampled parameter vector is evaluated as the mean of REPS stochastic 15-day episodes.
Outputs analysed are the three trade-off objectives (exposure, delay, availability loss), the
terminal backlog and the scalar reward.
"""
import numpy as np
from SALib.sample import sobol as sobol_sample
from SALib.analyze import sobol as sobol_analyze
from common import *
from sdmodel import calibrated, simulate
ca = json.load(open(os.path.join(RES, "calibration_arrivals.json")))
cs = json.load(open(os.path.join(RES, "calibration_severity_kev.json")))
base = calibrated(ca, cs)
problem = {"num_vars": 11, "names": ["lam", "cap", "h", "w_mult", "alpha", "beta1", "beta2", "B0", "nb_k", "p_mean", "eta"],
           "bounds": [[1.5, 4.5], [2.0, 4.5], [0.5, 2.0], [0.5, 2.0], [0.06, 0.24], [0.002, 0.008],
                      [0.003, 0.012], [4, 16], [1.0, 10.0], [0.03, 0.20], [0.0, 5e-4]]}
LABELS = {"lam": "Arrival rate λ", "cap": "Capacity c", "h": "Threat multiplier h", "w_mult": "Asset weight scale",
          "alpha": "Recovery α", "beta1": "Patch disruption β₁", "beta2": "Exposure disruption β₂",
          "B0": "Initial backlog B₀", "nb_k": "Arrival dispersion k", "p_mean": "Mean threat score", "eta": "KEV hazard η"}
N, REPS = 2048, 30
X = sobol_sample.sample(problem, N, calc_second_order=False, seed=SEED)
rng = np.random.default_rng(SEED)
outs = {k: np.zeros(len(X)) for k in ("exposure", "delay", "avail_loss", "B_end", "reward")}
CH = 700
for s in range(0, len(X), CH):
    x = np.repeat(X[s:s + CH], REPS, axis=0); R = len(x)
    p = dict(base, lam=x[:, 0], cap=x[:, 1], h=x[:, 2], w_lo=0.5 * x[:, 3], w_hi=1.5 * x[:, 3], alpha=x[:, 4],
             beta1=x[:, 5], beta2=x[:, 6], B0=x[:, 7], nb_k=x[:, 8], p_a=x[:, 9] * 3.3, p_b=(1 - x[:, 9]) * 3.3, eta=x[:, 10])
    o = simulate(p, R, rng, nmax=200)
    assert o["overflow_runs"] == 0 and o["conservation_error"] == 0
    for k in outs: outs[k][s:s + CH] = o[k].reshape(-1, REPS).mean(1)
res = {"N_base": N, "reps_per_sample": REPS, "n_model_evaluations": int(len(X)), "n_episodes": int(len(X) * REPS),
       "bounds": dict(zip(problem["names"], problem["bounds"])), "indices": {}}
for k, y in outs.items():
    si = sobol_analyze.analyze(problem, y, calc_second_order=False, seed=SEED, num_resamples=1000)
    res["indices"][k] = {nm: {"S1": float(si["S1"][i]), "S1_conf": float(si["S1_conf"][i]),
                              "ST": float(si["ST"][i]), "ST_conf": float(si["ST_conf"][i])} for i, nm in enumerate(problem["names"])}
    res["indices"][k]["_output_mean"] = float(y.mean()); res["indices"][k]["_output_sd"] = float(y.std())
    res["indices"][k]["_sum_S1"] = float(np.sum(si["S1"]))
save_json(res, "sobol_indices.json")
np.savez(os.path.join(RES, "sobol_samples.npz"), X=X, **outs)

fig, axes = plt.subplots(3, 1, figsize=(6.5, 8.1), sharex=True)
order = np.argsort([-res["indices"]["exposure"][n]["ST"] for n in problem["names"]])
names = [problem["names"][i] for i in order]; yy = np.arange(len(names))
for ax, (k, title) in zip(axes, [("exposure", "Exposure index"), ("delay", "Restricted mean delay"), ("avail_loss", "Availability loss")]):
    S1 = [res["indices"][k][n]["S1"] for n in names]; ST = [res["indices"][k][n]["ST"] for n in names]
    e1 = [res["indices"][k][n]["S1_conf"] for n in names]; eT = [res["indices"][k][n]["ST_conf"] for n in names]
    ax.barh(yy - 0.19, ST, 0.36, xerr=eT, color="#404040", edgecolor=INK, label="Total-order $S_T$", error_kw=dict(lw=0.7, ecolor=MUTED))
    ax.barh(yy + 0.19, np.clip(S1, 0, None), 0.36, xerr=e1, color="white", edgecolor=INK, hatch="////", label="First-order $S_1$", error_kw=dict(lw=0.7, ecolor=MUTED))
    ax.set_title(title, fontsize=10); ax.set_xlim(0, 0.6)
    ax.grid(axis="y", visible=False)
for a_ in axes: a_.set_yticks(yy); a_.set_yticklabels([LABELS[n] for n in names], fontsize=9); a_.invert_yaxis()
axes[0].legend(fontsize=8.5, loc="lower right"); axes[-1].set_xlabel("Sobol index")
fig.tight_layout(); fig.savefig(os.path.join(FIGS, "fig6_sobol_sensitivity.png")); plt.close(fig)
for k in ("exposure", "delay", "avail_loss"):
    print(k, sorted(((round(v["ST"], 3), n) for n, v in res["indices"][k].items() if not n.startswith("_")), reverse=True)[:5], "sumS1", round(res["indices"][k]["_sum_S1"], 3))
