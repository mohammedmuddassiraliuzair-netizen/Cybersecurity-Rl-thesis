"""Stage 2: calibrate the vulnerability-disclosure INFLOW of the SD model against real NVD data.

SD inflow structure:  N(t) = mu * exp(g * t/90) * s_dow(t)     (weekday factors normalised to mean 1)
Stock:                D(t+1) = D(t) + N(t)                     (cumulative disclosed vulnerabilities)

Step 1  Differential evolution (DE) point calibration: minimise squared error between simulated and
        observed daily inflow over the calibration window (Jun 17 - Sep 14, 2026; 90 days).
Step 2  Bayesian calibration: negative-binomial likelihood, weakly-informative priors, posterior by
        affine-invariant MCMC (emcee), initialised at the DE optimum.
Step 3  Out-of-sample check on the later window (Sep 15 - Oct 6, 2026) with posterior predictive bands.
"""
import numpy as np, pandas as pd, emcee
from scipy.optimize import differential_evolution
from scipy.special import gammaln
from common import *

n = pd.read_csv(os.path.join(DATA, "nvd_2026_window.csv"))
n = n[n.vulnStatus != "Rejected"]
daily = n.groupby("published").size()
days = pd.date_range("2026-06-17", "2026-10-06")
daily = daily.reindex(days.strftime("%Y-%m-%d"), fill_value=0).values.astype(float)
cal_idx = np.arange(90); hold_idx = np.arange(90, len(days))
dow = days.dayofweek.values                       # 0 = Monday
t = np.arange(len(days)) / 90.0
y_cal = daily[cal_idx]

def flow(theta, idx):
    mu, g = theta[0], theta[1]
    s = np.r_[theta[2:8], 0.0]                    # 6 free log-factors; Sunday is reference
    s = np.exp(s - s.mean())                      # normalise: geometric mean 1
    return mu * np.exp(g * t[idx]) * s[dow[idx]]

# ---- Step 1: differential evolution ------------------------------------------------------------
bounds = [(50, 1000), (-1.5, 1.5)] + [(-3, 3)] * 6
sse = lambda th: np.sum((flow(th, cal_idx) - y_cal) ** 2)
de = differential_evolution(sse, bounds, seed=SEED, tol=1e-10, maxiter=3000, polish=True)
th_de = de.x
sim_de = flow(th_de, cal_idx)

# ---- Step 2: Bayesian (negative binomial) ------------------------------------------------------
def logpost(p):
    th, logk = p[:-1], p[-1]
    if not (0 < th[0] < 5000 and -3 < th[1] < 3 and np.all(np.abs(th[2:]) < 5) and -3 < logk < 8):
        return -np.inf
    m = flow(th, cal_idx); k = np.exp(logk)
    ll = np.sum(gammaln(y_cal + k) - gammaln(k) - gammaln(y_cal + 1)
                + k * np.log(k / (k + m)) + y_cal * np.log(m / (k + m)))
    lp = -0.5 * ((np.log(th[0]) - np.log(300)) / 1.0) ** 2   # lognormal(300, 1) on base rate
    lp += -0.5 * (th[1] / 1.0) ** 2 - 0.5 * np.sum((th[2:] / 2.0) ** 2) - 0.5 * ((logk - 2) / 3) ** 2
    return ll + lp

ndim, nw = 9, 36
rng = np.random.default_rng(SEED)
p0 = np.r_[th_de, 2.5] + 1e-3 * rng.standard_normal((nw, ndim))
sampler = emcee.EnsembleSampler(nw, ndim, logpost)
sampler.random_state = np.random.RandomState(SEED).get_state()   # make MCMC reproducible
sampler.run_mcmc(p0, 20000, progress=False)
chain = sampler.get_chain(discard=5000, thin=20, flat=True)
acc = float(np.mean(sampler.acceptance_fraction))
try: tau = sampler.get_autocorr_time(discard=2000, quiet=True).tolist()
except Exception: tau = None

# posterior predictive (calibration + hold-out)
all_idx = np.arange(len(days)); draws = chain[rng.choice(len(chain), 2000, replace=False)]
pp = np.empty((len(draws), len(days)))
for i, d in enumerate(draws):
    m = flow(d[:-1], all_idx); k = np.exp(d[-1])
    pp[i] = rng.negative_binomial(k, k / (k + m))
lo, med, hi = np.percentile(pp, [5, 50, 95], axis=0)
mean_post = np.mean([flow(d[:-1], all_idx) for d in draws], axis=0)
cover_cal = float(np.mean((daily[cal_idx] >= lo[cal_idx]) & (daily[cal_idx] <= hi[cal_idx])))
cover_hold = float(np.mean((daily[hold_idx] >= lo[hold_idx]) & (daily[hold_idx] <= hi[hold_idx])))

names = ["mu", "g"] + [f"s_{d}" for d in ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]] + ["log_k"]
def wk(th):
    s = np.exp(np.r_[th[2:8], 0] - np.r_[th[2:8], 0].mean()); return dict(zip(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], s.round(4)))
post = {nm: {"mean": float(chain[:, i].mean()), "sd": float(chain[:, i].std()),
             "q05": float(np.percentile(chain[:, i], 5)), "q95": float(np.percentile(chain[:, i], 95))}
        for i, nm in enumerate(names)}
out = {"data": {"calibration_window": "2026-06-17..2026-09-14", "holdout_window": "2026-09-15..2026-10-06",
                "n_cal_days": 90, "n_hold_days": int(len(hold_idx)), "cal_total": int(y_cal.sum()),
                "cal_mean_per_day": float(y_cal.mean()), "cal_sd_per_day": float(y_cal.std(ddof=1)),
                "hold_mean_per_day": float(daily[hold_idx].mean())},
       "DE": {"theta": th_de.tolist(), "weekday_factors": wk(th_de), "SSE": float(de.fun), "nfev": int(de.nfev),
              "fit_daily": fit_stats(y_cal, sim_de),
              "fit_cumulative": fit_stats(np.cumsum(y_cal), np.cumsum(sim_de))},
       "Bayes": {"posterior": post, "weekday_factors_mean": wk(chain[:, :-1].mean(0)),
                 "dispersion_k_mean": float(np.exp(chain[:, -1]).mean()),
                 "acceptance": acc, "autocorr_time": tau, "n_samples": int(len(chain)),
                 "pp_coverage_90_cal": cover_cal, "pp_coverage_90_hold": cover_hold,
                 "fit_hold_postmean": fit_stats(daily[hold_idx], mean_post[hold_idx]),
                 "fit_hold_cumulative": fit_stats(np.cumsum(daily[hold_idx]), np.cumsum(mean_post[hold_idx]))}}
# ---- Reported quantities for thesis Tables D1 and X (reporting only; no effect on the simulation) -------
# The sampler parameterises weekday factors relative to their GEOMETRIC mean.  Eq. B5 and the simulator
# normalise them to an ARITHMETIC mean of 1 ("relative to an average day"), so the base rate is re-expressed
# on that scale as well: mu_avg = mu * mean(s_geo).  All intervals below are central 95% credible intervals.
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
def arith(th):
    s = np.exp(np.r_[th[2:8], 0.0] - np.r_[th[2:8], 0.0].mean())
    return th[0] * s.mean(), s / s.mean()
mu_ar = np.empty(len(chain)); f_ar = np.empty((len(chain), 7))
for i, d in enumerate(chain): mu_ar[i], f_ar[i] = arith(d[:-1])
q95 = lambda a: {"mean": float(np.mean(a)), "q025": float(np.percentile(a, 2.5)), "q975": float(np.percentile(a, 97.5))}
f_sim = np.array([out["Bayes"]["weekday_factors_mean"][d] for d in DAYS]); f_sim = f_sim / f_sim.mean()   # exactly as sdmodel.calibrated
mu_de_ar, f_de_ar = arith(th_de)
out["Bayes"]["reported_95"] = {
    "base_rate_avg_day_at_t0": q95(mu_ar), "trend_g_per_90d": q95(chain[:, 1]), "dispersion_k": q95(np.exp(chain[:, -1])),
    "weekday_factor_marginal_avg_day": {d: q95(f_ar[:, j]) for j, d in enumerate(DAYS)},
    "weekday_factor_used_in_simulator": dict(zip(DAYS, f_sim.round(4).tolist()))}
out["DE"]["reported"] = {"base_rate_avg_day_at_t0": float(mu_de_ar), "trend_g_per_90d": float(th_de[1]),
                         "weekday_factor_avg_day": dict(zip(DAYS, f_de_ar.round(4).tolist()))}
save_json(out, "calibration_arrivals.json")
np.save(os.path.join(RES, "arrival_posterior.npy"), chain)

# ---- Figures -----------------------------------------------------------------------------------
fig, ax = plt.subplots(2, 1, figsize=(6.5, 5.6), gridspec_kw={"height_ratios": [1.5, 1]})
x = days
ax[0].fill_between(x, lo, hi, color=C1, alpha=0.18, lw=0, label="Bayesian 90% posterior predictive band")
ax[0].plot(x, daily, color=INK, lw=1.0, marker="o", ms=2.2, label="Actual NVD daily disclosures")
ax[0].plot(x[cal_idx], sim_de, color=C2, lw=1.4, ls="-.", label="SD inflow, DE-calibrated")
ax[0].plot(x[hold_idx], mean_post[hold_idx], color=C1, lw=1.4, ls="--", label="SD inflow, posterior mean (out-of-sample)")
ax[0].axvline(x[90], color=MUTED, lw=0.8, ls=":"); ax[0].text(x[91], 1900, "hold-out", color=MUTED, fontsize=8.5)
ax[0].set_ylabel("CVEs published per day"); ax[0].legend(fontsize=8.5, loc="upper left", ncol=2)
cum = np.cumsum(daily); ax[1].plot(x, cum / 1000, color=INK, lw=1.6, label="Actual cumulative disclosures")
ax[1].plot(x[cal_idx], np.cumsum(sim_de) / 1000, color=C2, lw=1.2, ls="-.", label="SD stock D(t), DE")
ax[1].plot(x, np.cumsum(mean_post) / 1000, color=C1, lw=1.2, ls="--", label="SD stock D(t), posterior mean")
ax[1].set_ylabel("Cumulative CVEs (thousands)"); ax[1].legend(fontsize=8.5, loc="upper left")
for a in ax: a.tick_params(axis="x", labelsize=8)
import matplotlib.dates as mdates
for a_ in ax: a_.xaxis.set_major_formatter(mdates.DateFormatter("%b %d")); a_.tick_params(axis="x", rotation=30)
fig.savefig(os.path.join(FIGS, "fig7_arrival_calibration.png")); plt.close(fig)
print(json.dumps({k: out[k] for k in ("data",)}, indent=1)); print("DE", out["DE"]["fit_daily"], out["DE"]["weekday_factors"])
print("Bayes mu", post["mu"], "g", post["g"], "k", out["Bayes"]["dispersion_k_mean"], "acc", acc)
print("coverage cal/hold", cover_cal, cover_hold, out["Bayes"]["fit_hold_postmean"])
