"""Stage 4: calibrate the REMEDIATION OUTFLOW structure against published real-world remediation data
(Kenna Security & Cyentia Institute, Prioritization to Prediction Vol. 3, 2019; ~300 organisations).

SD structure (two parallel first-order outflows, i.e. a fast "routine patch" stream and a slow
"exception / compensating control" stream):
    dB_f/dt = f * N - B_f / tau_f ;   dB_s/dt = (1 - f) * N - B_s / tau_s
Cohort survival implied by this structure:  S(t) = f exp(-t/tau_f) + (1 - f) exp(-t/tau_s)

Step 1  DE: minimise squared error between model and published fraction-closed points (25/50/75%).
Step 2  Bayesian: logit-normal observation error, weakly-informative priors, MCMC (emcee).
Step 3  Independent check: implied monthly remediation capacity at steady state, 30 / E[lifetime],
        vs the report's separate statement that a typical firm closes about 1 in 10 open
        vulnerabilities per month.
"""
import numpy as np, pandas as pd, emcee
from scipy.optimize import differential_evolution
from common import *
rng = np.random.default_rng(SEED)
lit = pd.read_csv(os.path.join(DATA, "remediation_literature.csv"))
closed = lambda t, f, tf, ts: 1 - (f * np.exp(-t / tf) + (1 - f) * np.exp(-t / ts))
logit = lambda p: np.log(p / (1 - p))
res, curves = {}, {}
grid = np.linspace(0, 500, 501)
for grp in ["all_vulnerabilities", "known_exploit"]:
    d = lit[lit.group == grp]; t, y = d.days.values.astype(float), d.fraction_closed.values
    obj = lambda th: np.sum((closed(t, *th) - y) ** 2)
    de = differential_evolution(obj, [(0.01, 0.99), (1, 120), (60, 3000)], seed=SEED, tol=1e-14, maxiter=5000)
    f, tf, ts = de.x
    def lp(p):
        lf, ltf, lts, ls = p
        fr = 1 / (1 + np.exp(-lf)); tf_, ts_ = np.exp(ltf), np.exp(lts); sig = np.exp(ls)
        if not (0 < tf_ < ts_ < 1e4 and -4 < ls < 1): return -np.inf
        pr = np.clip(closed(t, fr, tf_, ts_), 1e-6, 1 - 1e-6)
        ll = -0.5 * np.sum(((logit(y) - logit(pr)) / sig) ** 2) - len(y) * ls
        prior = -0.5 * (lf / 1.5) ** 2 - 0.5 * ((ltf - np.log(30)) / 1.0) ** 2 - 0.5 * ((lts - np.log(365)) / 1.0) ** 2 - 0.5 * ((ls - np.log(0.1)) / 0.5) ** 2
        return ll + prior
    p0 = np.r_[logit(f), np.log(tf), np.log(ts), np.log(0.1)] + 1e-3 * rng.standard_normal((24, 4))
    s = emcee.EnsembleSampler(24, 4, lp); s.random_state = np.random.RandomState(SEED).get_state(); s.run_mcmc(p0, 12000, progress=False)
    ch = s.get_chain(discard=3000, thin=15, flat=True)
    F, TF, TS = 1 / (1 + np.exp(-ch[:, 0])), np.exp(ch[:, 1]), np.exp(ch[:, 2])
    life = F * TF + (1 - F) * TS
    q = lambda a: {"mean": float(a.mean()), "q025": float(np.percentile(a, 2.5)), "q975": float(np.percentile(a, 97.5))}
    cc = np.array([closed(grid, F[i], TF[i], TS[i]) for i in rng.choice(len(F), 500)])
    curves[grp] = (cc, t, y, closed(grid, f, tf, ts))
    res[grp] = {"DE": {"f_fast": f, "tau_fast_days": tf, "tau_slow_days": ts, "SSE": float(de.fun),
                       "pred_at_points": closed(t, f, tf, ts).tolist(),
                       "median_lifetime_days": float(grid[np.argmax(closed(grid, f, tf, ts) >= 0.5)]),
                       "mean_lifetime_days": float(f * tf + (1 - f) * ts),
                       "monthly_capacity_pct_steady_state": float(30 / (f * tf + (1 - f) * ts) * 100)},
                "Bayes": {"f_fast": q(F), "tau_fast_days": q(TF), "tau_slow_days": q(TS), "mean_lifetime_days": q(life),
                          "monthly_capacity_pct_steady_state": q(30 / life * 100),
                          "closed_within_15_days": q(closed(15.0, F, TF, TS)),
                          "acceptance": float(np.mean(s.acceptance_fraction))},
                "observed": {"days": t.tolist(), "fraction_closed": y.tolist()}}
save_json(res, "calibration_remediation.json")

fig, ax = plt.subplots(figsize=(6.5, 3.9))
for grp, c, lab in [("all_vulnerabilities", C1, "All vulnerabilities"), ("known_exploit", C6, "Known exploit")]:
    cc, t, y, de_curve = curves[grp]
    ax.fill_between(grid, *np.percentile(cc, [5, 95], 0), color=GRID if grp == "all_vulnerabilities" else "#c8c8c8", alpha=.6, lw=0)
    ax.plot(grid, de_curve, color=INK, lw=1.5, ls="-" if grp == "all_vulnerabilities" else "--", label=f"{lab}: SD two-stream outflow (DE)")
    ax.scatter(t, y, color=INK if grp == "all_vulnerabilities" else "white", marker="o" if grp == "all_vulnerabilities" else "s", edgecolor=INK, zorder=5, s=28)
ax.scatter([], [], color="white", edgecolor=INK, label="Published data points (Kenna/Cyentia 2019)")
ax.axvline(15, color=MUTED, ls=":", lw=0.8); ax.text(18, 0.04, "15-day episode horizon", color=MUTED, fontsize=8.5)
ax.set_xlabel("Days since vulnerability discovered in the enterprise"); ax.set_ylabel("Cumulative fraction remediated")
ax.set_ylim(0, 1); ax.legend(fontsize=8.5, loc="lower right")
fig.savefig(os.path.join(FIGS, "fig9_remediation_calibration.png")); plt.close(fig)
for g in res: print(g, json.dumps(res[g]["DE"]), "\n  Bayes:", {k: (round(v["mean"], 3) if isinstance(v, dict) else v) for k, v in res[g]["Bayes"].items()})
