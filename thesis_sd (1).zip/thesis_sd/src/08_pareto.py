"""Stage 8: Pareto-efficiency analysis of the remediation trade-off.

(A) Policy family on the calibrated SD model: the SD-prior decision rule with availability-cost weight
    omega_A in {0, ..., 200} and daily patch budget fraction u in [0.25, 1]; each configuration is
    evaluated on 600 episodes with common random numbers. Objectives (all minimised): mean exposure
    index, restricted mean delay, availability loss.  The non-dominated set is the Pareto frontier.
    Run at the thesis capacity (c = 4) and at the calibrated real-world capacity c_cal.
(B) The seven policies of the thesis experiment (Table XV, Table E3): Pareto (non-dominance) check on
    the reported objectives.
"""
import numpy as np
from common import *
from sdmodel import calibrated, simulate
ca = json.load(open(os.path.join(RES, "calibration_arrivals.json")))
cs = json.load(open(os.path.join(RES, "calibration_severity_kev.json")))
rc = json.load(open(os.path.join(RES, "run_and_compare.json")))
base = calibrated(ca, cs); c_cal = rc["capacity_DE"]["c_cal_all"]

def nondominated(F):
    F = np.asarray(F); nd = np.ones(len(F), bool)
    for i in range(len(F)):
        nd[i] = not np.any(np.all(F <= F[i], 1) & np.any(F < F[i], 1))
    return nd

omegas = np.array([0, 0.5, 1, 2, 5, 10, 20, 50, 100, 200.0]); budgets = np.arange(0.25, 1.001, 0.125)
grid = np.array([(o, u) for o in omegas for u in budgets]); REPS = 600
fam = {}
for label, cap in [("thesis capacity c = 4", 4.0), (f"calibrated capacity c = {c_cal:.2f}", c_cal)]:
    om = np.repeat(grid[:, 0], REPS); bu = np.repeat(grid[:, 1], REPS)
    o = simulate(dict(base, cap=cap), len(om), np.random.default_rng(SEED), omega_A=om, budget=bu, nmax=200)
    F = np.c_[[o[k].reshape(-1, REPS).mean(1) for k in ("exposure", "delay", "avail_loss")]].T
    nd3 = nondominated(F); nd2 = nondominated(F[:, [0, 2]])
    fam[label] = {"grid_omega_budget": grid.tolist(), "objectives_exposure_delay_availloss": F.tolist(),
                  "pareto_3obj": nd3.tolist(), "pareto_exposure_vs_availloss": nd2.tolist(),
                  "n_pareto_3obj": int(nd3.sum()), "n_pareto_2obj": int(nd2.sum()),
                  "default_rule_omega1_u1": F[np.where((grid[:, 0] == 1) & (grid[:, 1] == 1))[0][0]].tolist(),
                  "min_exposure_point": F[F[:, 0].argmin()].tolist(), "min_availloss_point": F[F[:, 2].argmin()].tolist()}
    # marginal trade-off along the 2-objective frontier: exposure reduction per unit availability loss
    P = F[nd2][np.argsort(F[nd2][:, 2])]
    fam[label]["frontier_slope_exposure_per_availloss"] = (np.diff(P[:, 0]) / np.diff(P[:, 2])).tolist()

# (B) policy arms of the Twin-Testing study (data/rl_twin_summary.csv, produced by the RL package)
import pandas as pd
_tw = pd.read_csv(os.path.join(DATA, "rl_twin_summary.csv"))
_names = {"B1": "CVSS-First (B1)", "B2": "EPSS-First (B2)", "B3": "KEV-First (B3)", "B4": "SD-Only (B4)",
          "M1": "Model-Free PPO (M1)", "M2P": "Placebo Residual (M2-P)", "M2": "Residual PPO (M2)"}
_g = lambda c, a, k: float(_tw[(_tw.condition == c) & (_tw.arm == a)][k].iloc[0])
arms = {_names[a]: (_g("normal", a, "exposure"), _g("normal", a, "delay")) for a in _names}
_conds = ["normal", "threat", "resource", "asset", "joint"]
stress = {_names[a]: [_g(c, a, "exposure") for c in _conds] for a in _names}
Fa = np.array(list(arms.values())); nda = nondominated(Fa)
Fs = np.array(list(stress.values())); nds = nondominated(Fs)
dom = lambda a, b: bool(np.all(np.array(stress[a]) <= np.array(stress[b])) and np.any(np.array(stress[a]) < np.array(stress[b])))
partB = {"nominal_exposure_delay_nondominated": dict(zip(arms, nda.tolist())),
         "five_condition_exposure_nondominated": dict(zip(stress, nds.tolist())),
         "M2_dominates_M1_all_conditions": dom(_names["M2"], _names["M1"]),
         "B4_dominates_M2_all_conditions": dom(_names["B4"], _names["M2"]),
         "B1_dominates_M2_all_conditions": dom(_names["B1"], _names["M2"]),
         "M2_vs_M1_exposure_reduction_pct_by_condition": dict(zip(["Nominal", "Threat", "Resource", "Asset", "Joint"],
              (100 * (1 - np.array(stress[_names["M2"]]) / np.array(stress[_names["M1"]]))).round(2).tolist()))}
save_json({"family": fam, "thesis_arms": partB, "c_cal": c_cal}, "pareto.json")

fig, ax = plt.subplots(2, 1, figsize=(6.5, 8.8))
for a_, (label, d) in zip(ax, fam.items()):
    F = np.array(d["objectives_exposure_delay_availloss"]); nd2 = np.array(d["pareto_exposure_vs_availloss"])
    om = np.array(d["grid_omega_budget"])[:, 1]
    sc = a_.scatter(F[:, 2], F[:, 0], c=om, cmap="Greys", vmin=0, vmax=1.05, s=26, edgecolor=MUTED, lw=0.4, zorder=3)
    P = F[nd2][np.argsort(F[nd2][:, 2])]
    a_.plot(P[:, 2], P[:, 0], color=C6, lw=1.6, marker="o", ms=4, zorder=4, label="Pareto frontier (non-dominated)")
    dr = d["default_rule_omega1_u1"]; a_.scatter(dr[2], dr[0], marker="*", s=220, color="white", edgecolor=INK, linewidths=1.2, zorder=5, label="SD prior as used in thesis (ω=1, u=1)")
    a_.set_xlabel("Availability loss (mean 1 − A)"); a_.set_ylabel("Mean exposure index"); a_.set_title(label.capitalize(), fontsize=10)
    a_.legend(fontsize=8.5, loc="lower left")
cb = fig.colorbar(sc, ax=ax, fraction=0.025, pad=0.02); cb.set_label("Patch budget fraction u", fontsize=8.5)
fig.savefig(os.path.join(FIGS, "fig13_pareto_frontier.png")); plt.close(fig)

fig, ax = plt.subplots(figsize=(6.5, 4.5))
cols = {"CVSS-First (B1)": C1, "EPSS-First (B2)": C4, "KEV-First (B3)": C4, "SD-Only (B4)": C3,
        "Model-Free PPO (M1)": C2, "Placebo Residual (M2-P)": MUTED, "Residual PPO (M2)": C6}
for (nm, (e, d)), nd in zip(arms.items(), nda):
    if nm == "KEV-First (B3)": continue                                  # identical to EPSS-First
    ax.scatter(e, d, s=70, color=cols[nm], edgecolor=INK, marker="D" if nd else "o", zorder=3)
    lab = nm.replace("EPSS-First (B2)", "EPSS-First (B2) = KEV-First (B3)") + (" (non-dominated)" if nd else "")
    off = {"CVSS-First (B1)": (14, 48), "SD-Only (B4)": (4, -50), "EPSS-First (B2)": (70, -30)}.get(nm, (8, 6))
    ax.annotate(lab, (e, d), textcoords="offset points", xytext=off, fontsize=8.5,
                arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.7) if nm in ("CVSS-First (B1)", "SD-Only (B4)", "EPSS-First (B2)") else None)
ax.set_xlabel("Nominal cumulative exposure (lower is better)"); ax.set_ylabel("Restricted mean delay, days")
ax.set_xlim(0.9, 1.95); ax.set_ylim(5.215, 5.405)
fig.savefig(os.path.join(FIGS, "fig14_pareto_thesis_arms.png")); plt.close(fig)
print(json.dumps(partB, indent=1))
for k, d in fam.items(): print(k, d["n_pareto_2obj"], d["n_pareto_3obj"], d["default_rule_omega1_u1"], d["min_exposure_point"], d["min_availloss_point"])
