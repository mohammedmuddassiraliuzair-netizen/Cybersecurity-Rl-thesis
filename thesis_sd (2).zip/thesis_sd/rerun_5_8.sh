#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/src"; export OPENBLAS_NUM_THREADS=1
for s in 05_run_and_compare 06_diagrams 07_sobol 08_pareto; do echo "== $s $(date +%T)"; python3 "$s.py"; done
cd ..; sha256sum data/* results/*.json > results/SHA256SUMS.txt; echo "SD RERUN COMPLETE $(date +%T)"
