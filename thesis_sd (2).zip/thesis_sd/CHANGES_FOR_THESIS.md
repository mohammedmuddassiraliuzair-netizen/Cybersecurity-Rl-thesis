# Numbers to update in the thesis after the reproducibility fix (Oct 14, 2026)

Cause 1: the MCMC samplers (emcee) were not seeded, so every Bayesian result varied slightly between
runs. Stages 2-4 now seed them with the master seed 20261007. The values below are the new,
permanently reproducible values (reference/ folder). Cause 2: Table D1 and the weekday factors were
reported on a different scale from the one the text and simulator use (see Disclosure inflow). Everything not listed is unchanged.
Search the thesis for each OLD value; most appear in more than one place (text, tables, notes).

## Global replacement
| Old | New | Where |
|---|---|---|
| calibrated capacity 2.28 | **2.24** (2.235) | Ch. IV text, Tables X, XII, C1, D5, E2, E3, Ch. VI, Figs. 7 & 13 (figures regenerated) |
| known-exploit capacity 2.33 | **2.42** | Ch. IV text, Tables X, D5 |
| 57 percent of assumed capacity / 0.57 | **56 percent / 0.56** | Ch. IV text, Table E3 |
| 68.7% remediated within 15 days at c = 4 | **67.1%** | Ch. IV text, Table D5 |

## Disclosure inflow (Ch. IV text, Tables X, D1, D2)
Important correction: the weekday factors in v3 (Tue 2.41, Sun 0.36) were scaled to the GEOMETRIC-mean day,
but the text says "relative to an average day" and Eq. B5 and the simulator use an ARITHMETIC mean of 1.
On the correct scale the factors are Tue 2.05 and Sun 0.31, which also match the raw data (2.13 and 0.29).
All values below come from results/calibration_arrivals.json (keys "reported_95" and "DE.reported").

| Quantity | Old | New |
|---|---|---|
| Ch. IV text: weekday factors "relative to an average day" | 2.41 on Tuesdays, 0.36 on Sundays | **2.05 on Tuesdays, 0.31 on Sundays** |
| Ch. IV text and Table X: dispersion k, 95% CrI | 2.72 (2.01 to 3.57) | **2.72 (2.00 to 3.57)** |
| Table X: weekday factors Mon...Sun (as used in the simulator) | 1.12, 2.41, 1.47, 1.28, 1.03, 0.53, 0.36 | **0.96, 2.05, 1.25, 1.09, 0.88, 0.46, 0.31** |
| Table X: trend g, 95% interval | 0.64 [0.20, 1.08] | **0.64 [0.19, 1.09]** |
| Table D2: max autocorrelation time | 121.5 steps | **115.3 steps** |
| Table D2 / XI: hold-out daily fit, posterior mean | R² 0.502; RMSE 264.5; MAPE 56.1%; U 0.211 | **R² 0.504; RMSE 262.6; MAPE 56.5%; U 0.210** |
| Table D2: hold-out cumulative fit | R² 0.989; RMSE 948; MAPE 13.7%; U 0.066 | **R² 0.989; RMSE 953; MAPE 13.8%; U 0.067** |
| Unchanged | trend 0.64, acceptance 0.435, coverage 96.7% / 100%, all DE fit statistics | — |

New Table D1 (replace all rows; DE | posterior mean | 95% CrI):
| Parameter | DE | Posterior mean | 95% CrI |
|---|---|---|---|
| Base rate on an average day at t = 0 (CVEs/day) | 238.6 | 267.8 | [204.8, 350.2] |
| Trend g (per 90 days) | 0.789 | 0.643 | [0.188, 1.087] |
| Weekday factor, Mon | 0.969 | 0.962 | [0.690, 1.307] |
| Weekday factor, Tue | 2.137 | 2.046 | [1.543, 2.640] |
| Weekday factor, Wed | 1.163 | 1.254 | [0.909, 1.686] |
| Weekday factor, Thu | 1.060 | 1.086 | [0.783, 1.474] |
| Weekday factor, Fri | 0.934 | 0.886 | [0.630, 1.216] |
| Weekday factor, Sat | 0.475 | 0.457 | [0.320, 0.641] |
| Weekday factor, Sun | 0.263 | 0.309 | [0.213, 0.439] |
| Dispersion k | — | 2.720 | [1.998, 3.572] |
Table D1 note, replace with: "Weekday factors are normalized to an arithmetic mean of one, so each is relative to
an average day (Eq. B5). The sampler draws log-factors relative to Sunday and a base rate on the geometric-mean
scale, with priors Lognormal(ln 300, 1) on that rate, Normal(0, 1) on g, Normal(0, 2²) on each log-factor and
Normal(2, 3²) on ln k;
the table re-expresses every draw on the arithmetic scale. The factors used by the simulator (Table X), evaluated
at the posterior-mean parameters, differ from the marginal means by at most 0.006."

## KEV escalation (Table D3, Table X)
| Quantity | Old | New |
|---|---|---|
| Listing probability per 1,000 | 2.15 [1.65, 2.72] | **2.16 [1.65, 2.73]** |
| Time constant τK | 17.6 d [12.7, 24.5] | **17.6 d [12.9, 24.5]** |
| Hazard η (also Table X) | 1.26 × 10⁻⁴ [0.86, 1.77] | **1.25 × 10⁻⁴ [0.85, 1.75]** |

## Remediation posterior (Table D4) — DE columns unchanged
| Group / quantity | Old | New |
|---|---|---|
| All: τf | 35.8 [15.9, 64.1] | **36.0 [16.4, 64.1]** |
| All: τs | 519 [330, 1120] | **522 [331, 1103]** |
| All: mean lifetime | 301 [237, 462] | **301 [236, 461]** |
| All: within 15 days | 16.4% [12.9, 21.0] | **16.5% [13.0, 21.0]** |
| Known exploit: f | 0.522 [0.305, 0.724] | **0.521 [0.307, 0.720]** |
| Known exploit: τf | 35.7 [17.2, 54.6] | **35.7 [17.8, 54.0]** |
| Known exploit: τs | 541 [228, 1904] | **522 [225, 1705]** |
| Known exploit: mean lifetime | 242 [157, 588] | **237 [156, 531]** |
| Known exploit: monthly capacity | 13.9 [5.1, 19.1] | **14.0 [5.7, 19.2]** |
| Known exploit: within 15 days | 19.9% [16.8, 24.1] | **19.9% [16.7, 23.7]** |

## Table XII (Original column unchanged)
| Output | Calibrated c = 4: old → new | Calibrated c = 2.28 → **2.24**: old → new |
|---|---|---|
| Mean exposure | 0.623 [0.438, 0.824] → **0.618 [0.446, 0.826]** | 1.352 [1.073, 1.719] → **1.398 [1.137, 1.713]** |
| Delay (days) | 2.19 [1.81, 2.60] → **2.18 [1.81, 2.60]** | 4.60 [4.15, 5.07] → **4.70 [4.23, 5.21]** |
| Unresolved at day 15 | 13.9% (same) | 44.1% → **45.3%** |
| Backlog at day 15 | 8.5 (same) | 25.3 → **26.2** |
| Availability loss | 0.0738 → **0.0736** | 0.0665 → **0.0668** |
| Patches per episode | 46.6 → **46.5** | 29.6 → **29.0** |
| Cumulative reward | −10.87 → **−10.81** | −20.28 → **−20.86** |
Text after Table XII: "raises mean exposure by 44 percent" → **43 percent** (delay 36 percent unchanged).

## Sobol indices (Table E1, first-order / total-order; Ch. VI text)
| Parameter | Exposure | Delay | Availability loss |
|---|---|---|---|
| Arrival rate λ | 0.212 / **0.321** | **0.196 / 0.233** | **0.141 / 0.181** |
| Capacity c | **0.064 / 0.123** | 0.359 / **0.383** | 0.001 / **0.024** |
| Threat multiplier h | **0.119 / 0.225** | **0.003** / 0.020 | **0.100 / 0.143** |
| Asset-weight scale | **0.130 / 0.239** | 0.000 / **0.020** | **0.107 / 0.155** |
| Recovery α | **0.000 / 0.012** | **0.003 / 0.012** | **0.076** / 0.099 |
| Patch disruption β₁ | 0.000 / 0.014 | **0.086 / 0.236** | **0.052** / 0.085 |
| Exposure disruption β₂ | **0.000** / 0.011 | 0.000 / 0.013 | **0.086 / 0.146** |
| Initial backlog B₀ | **0.046 / 0.081** | **0.141 / 0.152** | **0.063 / 0.090** |
| Arrival dispersion k | **0.000 / 0.011** | 0.000 / **0.013** | **0.000** / 0.007 |
| Mean threat score | **0.184 / 0.312** | **0.047 / 0.179** | **0.219 / 0.282** |
| KEV hazard η | 0.000 / **0.012** | 0.000 / **0.012** | 0.000 / 0.007 |
| Sum of first-order | **0.743** | **0.826** | **0.841** |
Small negative first-order estimates (Monte Carlo noise) are reported as 0.000.
Ch. VI text: "arrival rate (ST = 0.33), mean threat score (0.31)" → **0.32, 0.31**; capacity for delay 0.38 unchanged;
"0.014 or less" for k and η is still true (now 0.013 or less).

## Figures
Replace every figure with the files in figs/. Fig. 14 (fig14_pareto_thesis_arms.png) now has non-overlapping labels
and labels EPSS-first and KEV-first as identical. Figs. 7 and 13 now show c = 2.24.

## Pareto frontier (Ch. VI text, Table E2, Fig. 13)
| Claim | Old | New |
|---|---|---|
| Efficient configurations at c = 4 | 10 of 70 | 10 of 70 (same count; membership changed, see below) |
| Frontier end points at c = 4 | exposure 0.598 at loss 0.0733 → 2.04 at 0.0497 | **0.606 at 0.0739 → 2.075 at 0.0500** |
| Thesis rule (ω=1,u=1) at c = 4 | 0.617 / 2.18 / 0.0739 | **0.619 / 2.18 / 0.0743** |
| ω = 0.5 improvement at c = 4 (exposure / delay / availability loss) | −3.1% / −1.5% / −0.8% | **−1.5% / −1.1% / −1.2%** |
| Lowest exposure at calibrated capacity | 1.332 (+123%) | **1.370 (+126%)** |
| Thesis rule at calibrated capacity | 1.377 / 4.64 / 0.0672 | **1.402 / 4.73 / 0.0671** |
| ω = 0.5 improvement at calibrated capacity | exposure −3.2%, availability −1.6% | **exposure −2.3%, delay −1.5%, availability −1.5%** |

New Table E2 rows (ωA, u: exposure, delay, availability loss):
c = 4: 5, 1.000: 2.075, 7.68, 0.0500 | 2, 0.500: 1.881, 6.58, 0.0560 | 2, 0.625: 1.587, 5.76, 0.0590 |
2, 0.750: 1.422, 5.17, 0.0602 | 2, 1.000: 0.982, 4.14, 0.0609 | 0.5, 0.750: 0.940, 3.31, 0.0690 |
1, 0.875: 0.761, 2.71, 0.0715 | 0, 0.875: 0.756, 2.69, 0.0715 | 0.5, 1.000: 0.610, 2.16, 0.0733 |
0, 1.000: 0.606, 2.18, 0.0739 | thesis rule (dominated) 1, 1.000: 0.619, 2.18, 0.0743
c = 2.24: 5, 1.000: 2.277, 8.00, 0.0525 | 2, 0.875: 1.928, 6.66, 0.0571 | 2, 1.000: 1.667, 6.13, 0.0571 |
1, 0.875: 1.540, 5.17, 0.0648 | 0.5, 1.000: 1.370, 4.65, 0.0661 | thesis rule (dominated) 1, 1.000: 1.402, 4.73, 0.0671

## Unchanged conclusions
Capacity is the dominant driver of delay; exposure is driven by arrival rate, threat score, asset weights
and threat multiplier; calibrated capacity sits in the resource-stress regime; the thesis rule is
Pareto-dominated by ωA = 0.5 at both capacities; M2 Pareto-dominates M1 (Part B, unchanged).

## Appendix F wording
Replace the reproducibility sentence with: "All random number generators, including the MCMC samplers,
are seeded with master seed 20261007; two independent runs produce byte-for-byte identical results, and
./verify.sh checks a new run against the reference results."  Also update Table C2 to say the remediation
file has 9 rows, of which 6 are used.
