"""Reference implementation of the enterprise vulnerability-management System Dynamics model
(thesis Chapter IV equations), vectorised over R independent runs.

Stocks   : open vulnerabilities in three FIFO severity queues (backlog B = sum of queues),
           availability A, cumulative exposure.
Flows    : arrivals N_t (disclosure inflow), patches P_t (remediation outflow, policy-controlled),
           KEV escalation (threat inflow on open items), availability recovery / disruption.
Equations: B_{t+1} = B_t + N_t - P_t
           E_t     = sum_i min(1, h p_i) w_i                     (open items)
           A_{t+1} = clip(A_t + alpha (1 - A_t) - beta1 P_t - beta2 E_t, A_min, 1)
           D_t     = beta1 P_t + beta2 E_t
           r_t     = -(0.5 E_t + 0.03 B_{t+1} + 4 L_t),  L_t = beta1 P_t + beta2 E_t   (revised, spec D2)
           c_t     = min(c, floor(c u A_t (1 - f_t))), f_t = min(0.25, h B_t/(B_t+30))   (spec D1)
Decision rule: the SD prior (Chapter V) - choose the feasible action minimising J(a).
Order within a day: exposure measured -> policy patches items present at start of day -> arrivals
join the queues -> open items may escalate to KEV.
"""
import itertools, numpy as np

ACTIONS = np.array([a for a in itertools.product(range(5), repeat=3) if sum(a) <= 4])   # 35 actions

ORIGINAL = dict(  # thesis Table X (pre-calibration values)
    lam=3.0, nb_k=None, dow=None, trend=0.0, share=(0.1252, 0.5121, 0.3627),
    B0=8, cap=4.0, alpha=0.12, beta1=0.004, beta2=0.006, A_min=0.6, h=1.0, w_lo=0.5, w_hi=1.5,
    p_a=0.3, p_b=3.0, eta=0.0, p_kev=1.0, closure=7, H=15, horizon_prior=5)

def calibrated(cal_arr, cal_sev, start_dow=0):
    """Map calibration outputs to model parameters (enterprise scaled so mean arrivals = 3/day)."""
    p = dict(ORIGINAL)
    wk = cal_arr["Bayes"]["weekday_factors_mean"]
    f = np.array([wk[d] for d in ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]]); f = f / f.mean()
    p.update(lam=3.0, nb_k=cal_arr["Bayes"]["dispersion_k_mean"], dow=np.roll(f, -start_dow),
             trend=cal_arr["Bayes"]["posterior"]["g"]["mean"] / 90.0,
             share=tuple(cal_sev["severity"]["queue_share_mean"]),
             eta=cal_sev["kev"]["eta_daily_mean"])
    return p

def simulate(p, R, rng, policy="sd", omega_A=1.0, budget=1.0, nmax=160, record=False, return_items=False):
    """Run R independent episodes with the SD-prior decision rule (cost minimiser over the 35 actions).
    Any numeric parameter in p, and omega_A / budget, may be a scalar or an array of length R
    (one value per run), which is how the Sobol and Pareto experiments are vectorised.
    omega_A scales the availability (disruption) cost in the SD prior; budget caps patches at budget*cap."""
    V = lambda x: np.broadcast_to(np.asarray(x, float), (R,)).copy()
    H = int(p["H"]); lam, cap0, h = V(p["lam"]), V(p["cap"]), V(p["h"])
    alpha, b1, b2, Amin = V(p["alpha"]), V(p["beta1"]), V(p["beta2"]), V(p["A_min"])
    eta, pa, pb = V(p["eta"]), V(p["p_a"]), V(p["p_b"]); wlo, whi = V(p["w_lo"]), V(p["w_hi"])
    B0 = V(p["B0"]).round().astype(int); omA, bud = V(omega_A), V(budget)
    nbk = None if p["nb_k"] is None else V(p["nb_k"])
    share = np.asarray(p["share"], float); share = share / share.sum()
    q = np.full((R, nmax), -1); pr = np.zeros((R, nmax)); w = np.zeros((R, nmax))
    born = np.full((R, nmax), -1); done_t = np.full((R, nmax), -1); kev = np.zeros((R, nmax), bool)
    n_items = np.zeros(R, int); A = np.ones(R); J_IDX = np.arange(nmax)[None, :]
    def add(counts, t):
        c = np.minimum(counts, nmax - n_items)
        m = (J_IDX >= n_items[:, None]) & (J_IDX < (n_items + c)[:, None])
        q[m] = rng.choice(3, size=m.sum(), p=share)
        pr[m] = rng.beta(np.broadcast_to(pa[:, None], m.shape)[m], np.broadcast_to(pb[:, None], m.shape)[m])
        w[m] = rng.uniform(np.broadcast_to(wlo[:, None], m.shape)[m], np.broadcast_to(whi[:, None], m.shape)[m])
        born[m] = t; n_items[:] += c
    add(B0, 0)
    out = {k: np.zeros(R) for k in ("exposure", "reward", "patches", "avail_loss", "D")}
    traj = {"B": [], "E": [], "A": [], "P": [], "N": []}
    npatch = ACTIONS.sum(1)[None, :]; Hp = p["horizon_prior"]
    for t in range(H):
        openm = (born >= 0) & (done_t < 0)
        thr = np.where(kev, np.maximum(pr, p["p_kev"]), pr)
        e_i = np.minimum(1.0, h[:, None] * thr) * w * openm
        E = e_i.sum(1); B = openm.sum(1)
        # capacity: maintenance closure every `closure`-th day; stochastic rounding of fractional capacity
        # capacity with availability and emergency-work feedback (RL environment, Equation 5):
        # c = min(cap0, floor(cap0 * budget * A * (1 - f))), f = min(0.25, h * B / (B + 30)); 0 on closure days
        f_em = np.minimum(0.25, h * B / (B + 30.0))
        c = cap0 * bud * A * (1 - f_em) * (0.0 if (t + 1) % p["closure"] == 0 else 1.0)
        cap = np.minimum(np.floor(cap0), np.floor(c + 1e-12))
        # per-queue FIFO ranks and exposure removed by patching the first n items of each queue
        rank = np.zeros((R, nmax), int); gains = np.zeros((R, 3, 5)); qlen = np.zeros((R, 3), int)
        for k in range(3):
            mk = openm & (q == k); rk = np.cumsum(mk, 1) * mk; rank += rk; qlen[:, k] = mk.sum(1)
            for n in range(1, 5): gains[:, k, n] = (e_i * (mk & (rk <= n))).sum(1)
        feas = (ACTIONS[None, :, :] <= qlen[:, None, :]).all(2) & (npatch <= cap[:, None])
        g = gains[:, 0, ACTIONS[:, 0]] + gains[:, 1, ACTIONS[:, 1]] + gains[:, 2, ACTIONS[:, 2]]
        # SD prior (mirrors the reward): Hp-day holding cost of residual exposure (incl. exposure-driven
        # disruption 4*beta2*E) and backlog, plus patch cost and anticipated patch disruption 4*omega_A*beta1*P
        # revised SD prior (spec D2/D4): reward -(0.5E + 0.03B + 4L), L = b1 P + b2 E; no separate patch cost
        J = ((0.5 + 4 * b2[:, None]) * Hp * (E[:, None] - g) + 0.03 * Hp * (B[:, None] - npatch)
             + 4 * omA[:, None] * (b1[:, None] * npatch) * Hp)
        a = np.where(feas, J, np.inf).argmin(1)
        act = ACTIONS[a]; P = act.sum(1)
        for k in range(3):
            done_t[openm & (q == k) & (rank > 0) & (rank <= act[:, k][:, None])] = t
        D = b1 * P + b2 * E
        mu = lam * np.exp(p["trend"] * t) * (p["dow"][t % 7] if p["dow"] is not None else 1.0)
        N = rng.poisson(mu) if nbk is None else rng.negative_binomial(nbk, nbk / (nbk + mu))
        add(N, t + 1)
        openm2 = (born >= 0) & (done_t < 0)
        kev |= openm2 & (rng.random((R, nmax)) < eta[:, None])
        B1 = openm2.sum(1)
        out["reward"] += -(0.5 * E + 0.03 * B1 + 4 * D)                  # revised reward (spec D2), original units
        out["exposure"] += E / H; out["patches"] += P; out["D"] += D; out["avail_loss"] += (1 - A) / H
        A = np.clip(A + alpha * (1 - A) - b1 * P - b2 * E, Amin, 1.0)
        if record:
            for nm, v in zip(("B", "E", "A", "P", "N"), (B, E, A, P, N)): traj[nm].append(np.asarray(v, float).copy())
    tot = born >= 0
    delay = np.where(done_t >= 0, done_t - born + 1, H - born)
    out["delay"] = (delay * tot).sum(1) / tot.sum(1)
    out["unresolved"] = ((done_t < 0) & tot).sum(1) / tot.sum(1)
    out["B_end"] = ((done_t < 0) & tot).sum(1).astype(float)
    out["conservation_error"] = float(np.abs(out["B_end"] - (tot.sum(1) - out["patches"])).max())
    out["overflow_runs"] = int((n_items >= nmax).sum())
    if return_items: out["born"], out["done_t"] = born, done_t
    if record: out["traj"] = {k: np.array(v) for k, v in traj.items()}
    return out
