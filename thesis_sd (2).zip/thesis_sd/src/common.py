"""Shared helpers: paths, plotting style, fit statistics (Sterman 2000, ch. 21)."""
import os, json, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA, FIGS, RES = (os.path.join(ROOT, d) for d in ("data", "figs", "results"))
SEED = 20261007
INK, MUTED, GRID = "#000000", "#000000", "#ffffff"          # monochrome (print) style
C1 = C2 = C3 = C4 = C5 = C6 = "#000000"   # strictly black and white
plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 9.5, "axes.labelsize": 9.5, "xtick.labelsize": 9, "ytick.labelsize": 9, "legend.fontsize": 8.5, "axes.titlesize": 9.5, "axes.edgecolor": MUTED,
    "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED, "axes.spines.top": False,
    "axes.spines.right": False, "axes.grid": False, "hatch.linewidth": 0.5, "grid.color": GRID, "grid.linewidth": 0.6,
    "legend.frameon": False, "figure.dpi": 300, "savefig.bbox": "tight"})

def fit_stats(obs, sim):
    obs, sim = np.asarray(obs, float), np.asarray(sim, float)
    mse = np.mean((sim - obs) ** 2)
    r = np.corrcoef(obs, sim)[0, 1]
    sd_o, sd_s = obs.std(), sim.std()
    um = (sim.mean() - obs.mean()) ** 2 / mse
    us = (sd_s - sd_o) ** 2 / mse
    uc = 2 * (1 - r) * sd_s * sd_o / mse
    return {"R2": float(r ** 2), "RMSE": float(np.sqrt(mse)),
            "MAPE_pct": float(np.mean(np.abs(sim - obs) / np.maximum(np.abs(obs), 1e-9)) * 100),
            "Theil_U": float(np.sqrt(mse) / (np.sqrt(np.mean(sim ** 2)) + np.sqrt(np.mean(obs ** 2)))),
            "U_M_bias": float(um), "U_S_variance": float(us), "U_C_covariance": float(uc)}

def save_json(obj, name):
    with open(os.path.join(RES, name), "w") as f: json.dump(obj, f, indent=2, default=float)
