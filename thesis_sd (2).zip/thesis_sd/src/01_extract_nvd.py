"""Stage 1: extract NVD CVE records (fkie-cad/nvd-json-data-feeds snapshot) into a compact CSV.
Fields: cve, published (UTC date), vulnStatus, cvss31 base score (NVD primary preferred, else first secondary)."""
import json, glob, csv, sys, os
root = sys.argv[1]; out = sys.argv[2]
rows = []
for yr in ("CVE-2025", "CVE-2026"):
    for f in glob.glob(os.path.join(root, yr, "*", "*.json")):
        d = json.load(open(f))
        pub = d.get("published", "")[:10]
        if not ("2026-06-01" <= pub <= "2026-10-07"):
            continue
        score = ""; src = ""
        for m in d.get("metrics", {}).get("cvssMetricV31", []):
            if m.get("type") == "Primary" or score == "":
                score = m["cvssData"]["baseScore"]; src = m.get("type", "")
                if src == "Primary": break
        rows.append((d["id"], pub, d.get("vulnStatus", ""), score, src))
rows.sort(key=lambda r: (r[1], r[0]))
with open(out, "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["cve", "published", "vulnStatus", "cvss31", "cvss31_type"]); w.writerows(rows)
print(len(rows), "records written")
