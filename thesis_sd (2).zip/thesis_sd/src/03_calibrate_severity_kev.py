"""Stage 3: Bayesian calibration of (a) the severity mix routing arrivals into the three SD queues and
(b) the threat-escalation flow (CVE -> CISA KEV listing), from real NVD and KEV data.

(a) Dirichlet-multinomial: counts of critical (>=9), high [7,9), medium/low (<7), missing CVSS 3.1,
    Dirichlet(1,1,1,1) prior -> Dirichlet posterior.  Missing scores are imputed with the
    training-period median (Jun 18 - Aug 1) as in the thesis pipeline.
(b) Cure-fraction escalation model with right censoring at the KEV snapshot date:
        P(listed by lag L) = pi * (1 - exp(-L / tau))
    posterior for (pi, tau) by MCMC; daily per-item escalation hazard eta = pi / tau.
(c) Differential evolution fit of an SD inflow (constant rate + trend) to the cumulative KEV catalog
    in 2025-2026 to display the actual trend.
"""
import numpy as np, pandas as pd, emcee
from scipy.optimize import differential_evolution
from common import *
rng = np.random.default_rng(SEED)

n = pd.read_csv(os.path.join(DATA, "nvd_2026_window.csv"))
n = n[(n.vulnStatus != "Rejected") & (n.published >= "2026-06-17") & (n.published <= "2026-09-14")].copy()
train_med = float(n[(n.published >= "2026-06-18") & (n.published <= "2026-08-01")].cvss31.median())
miss = n.cvss31.isna()
s = n.cvss31.fillna(train_med)
q = np.where(s >= 9, 0, np.where(s >= 7, 1, 2))
counts = np.array([np.sum((q == 0) & ~miss), np.sum((q == 1) & ~miss), np.sum((q == 2) & ~miss), miss.sum()])
alpha_post = 1 + counts
dir_draws = rng.dirichlet(alpha_post, 20000)
queue_draws = np.c_[dir_draws[:, 0], dir_draws[:, 1] + (dir_draws[:, 3] if train_med >= 7 else 0),
                    dir_draws[:, 2] + (dir_draws[:, 3] if train_med < 7 else 0)]
sev = {"train_median_cvss31": train_med, "counts_crit_high_medlow_missing": counts.tolist(),
       "queue_share_mean": queue_draws.mean(0).tolist(),
       "queue_share_q025": np.percentile(queue_draws, 2.5, 0).tolist(),
       "queue_share_q975": np.percentile(queue_draws, 97.5, 0).tolist(),
       "cvss_observed_quantiles": {str(p): float(np.nanpercentile(n.cvss31, p)) for p in (10, 25, 50, 75, 90)}}
# weekly trend of shares (actual data)
n["week"] = pd.to_datetime(n.published).dt.to_period("W").dt.start_time
n["queue"] = q
wk = n.groupby(["week", "queue"]).size().unstack(fill_value=0)
wk = wk.div(wk.sum(axis=1), axis=0)

# ---- (b) KEV escalation ------------------------------------------------------------------------
kj = json.load(open(os.path.join(DATA, "kev_catalog.json")))
kev = pd.DataFrame(kj["vulnerabilities"]); kev["dateAdded"] = pd.to_datetime(kev.dateAdded)
snap = pd.Timestamp(kj["dateReleased"][:10])
m = n.merge(kev[["cveID", "dateAdded"]], left_on="cve", right_on="cveID", how="left")
pub = pd.to_datetime(m.published)
event = m.dateAdded.notna().values
lag = np.clip(((m.dateAdded - pub).dt.days.fillna(0)).values, 0, None).astype(float)
T = (snap - pub).dt.days.values.astype(float)
lag_e = lag[event] + 0.5

def lp_kev(p):
    lpi, ltau = p
    if not (-15 < lpi < 0 and -3 < ltau < 7): return -np.inf
    pi, tau = np.exp(lpi), np.exp(ltau)
    ll = np.sum(np.log(pi) - np.log(tau) - lag_e / tau)
    ll += np.sum(np.log1p(-pi * (1 - np.exp(-T[~event] / tau))))
    return ll - 0.5 * ((ltau - np.log(14)) / 2) ** 2          # weak prior: tau ~ lognormal(14 d, sd 2 on log)
sam = emcee.EnsembleSampler(16, 2, lp_kev)
sam.random_state = np.random.RandomState(SEED).get_state()       # make MCMC reproducible
sam.run_mcmc(np.c_[np.log(0.002), np.log(10)] + 0.01 * rng.standard_normal((16, 2)), 8000, progress=False)
ch = sam.get_chain(discard=2000, thin=10, flat=True)
pi_d, tau_d = np.exp(ch[:, 0]), np.exp(ch[:, 1]); eta_d = pi_d / tau_d
kevres = {"window_cves": int(len(m)), "kev_listed": int(event.sum()), "snapshot": str(snap.date()),
          "lag_days_median": float(np.median(lag[event])), "lag_days_mean": float(lag[event].mean()),
          "pi_mean": float(pi_d.mean()), "pi_q025": float(np.percentile(pi_d, 2.5)), "pi_q975": float(np.percentile(pi_d, 97.5)),
          "tau_mean": float(tau_d.mean()), "tau_q025": float(np.percentile(tau_d, 2.5)), "tau_q975": float(np.percentile(tau_d, 97.5)),
          "eta_daily_mean": float(eta_d.mean()), "eta_q025": float(np.percentile(eta_d, 2.5)), "eta_q975": float(np.percentile(eta_d, 97.5)),
          "acceptance": float(np.mean(sam.acceptance_fraction))}

# ---- (c) KEV catalogue growth: actual trend + DE-fitted SD inflow ------------------------------
k2 = kev[kev.dateAdded >= "2025-01-01"].groupby("dateAdded").size()
dd = pd.date_range("2025-01-01", snap); k2 = k2.reindex(dd, fill_value=0)
base = int((kev.dateAdded < "2025-01-01").sum()); cum = base + k2.cumsum().values
tt = np.arange(len(dd)) / 365.0
sim = lambda th: base + np.cumsum(th[0] * np.exp(th[1] * tt))
de = differential_evolution(lambda th: np.sum((sim(th) - cum) ** 2), [(0.01, 10), (-2, 2)], seed=SEED, tol=1e-12)
kevres["catalog_DE"] = {"rate_per_day_at_2025_01_01": float(de.x[0]), "growth_per_year": float(de.x[1]),
                        "fit": fit_stats(cum, sim(de.x)), "catalog_size_at_snapshot": int(cum[-1]),
                        "additions_2025": int(k2[k2.index.year == 2025].sum()), "additions_2026_to_snapshot": int(k2[k2.index.year == 2026].sum())}
np.save(os.path.join(RES, "kev_posterior.npy"), ch)

fig, ax = plt.subplots(3, 1, figsize=(6.5, 7.9))
for j, (lab, c) in enumerate(zip(["Critical (CVSS >= 9)", "High (7 to < 9, incl. imputed)", "Medium/Low (< 7)"], [C6, C2, C1])):
    ax[0].plot(wk.index, wk[j], marker=["o", "s", "^"][j], ls=["-", "--", ":"][j], ms=3, color=c, lw=1.2, label=lab)
    ax[0].axhline(sev["queue_share_mean"][j], color=c, lw=0.8, ls="--")
ax[0].set_ylabel("Share of weekly disclosures"); ax[0].set_title("(a) Severity mix: weekly actual vs posterior", fontsize=9.5)
ax[0].set_ylim(0, 0.86); ax[0].legend(fontsize=8.5, loc="upper center", ncol=3, columnspacing=0.8, handlelength=1.6); ax[0].tick_params(axis="x", rotation=45, labelsize=8.5)
grid = np.arange(0, 91)
surv, cdf = 1.0, []                                   # Kaplan-Meier cumulative incidence (right-censored)
for g in grid:
    at_risk = np.sum((T >= g) & (~event | (lag >= g))); d_g = np.sum(event & (lag == g))
    surv *= (1 - d_g / at_risk) if at_risk > 0 else 1.0; cdf.append(1 - surv)
cdf = np.array(cdf)
kevres["km_incidence_per_1000_at_30_60_90"] = [float(cdf[30]*1000), float(cdf[60]*1000), float(cdf[90]*1000)]
draw = rng.choice(len(pi_d), 400)
curves = np.array([pi_d[i] * (1 - np.exp(-grid / tau_d[i])) for i in draw])
ax[1].fill_between(grid, *np.percentile(curves, [5, 95], 0) * 1000, facecolor="none", edgecolor=INK, hatch="////", lw=0, label="Posterior 90% band")
ax[1].plot(grid, np.median(curves, 0) * 1000, color=C1, lw=1.4, label="SD escalation model")
ax[1].step(grid, cdf * 1000, where="post", color=INK, lw=1.1, label="Actual (Kaplan-Meier)")
ax[1].set_xlabel("Days since NVD publication"); ax[1].set_ylabel("KEV-listed per 1,000 CVEs")
ax[1].set_title("(b) Threat escalation to KEV", fontsize=9.5); ax[1].legend(fontsize=8.5)
ax[2].plot(dd, cum, color=INK, lw=1.6, label="Actual KEV catalogue size")
ax[2].plot(dd, sim(de.x), color=C2, lw=1.2, ls="--", label="SD stock, DE-calibrated")
ax[2].set_ylabel("KEV entries"); ax[2].set_title("(c) KEV catalogue growth 2025-2026", fontsize=9.5)
ax[2].legend(fontsize=8.5); ax[2].tick_params(axis="x", rotation=45, labelsize=8.5)
save_json({"severity": sev, "kev": kevres}, "calibration_severity_kev.json")
fig.tight_layout(); fig.savefig(os.path.join(FIGS, "fig8_severity_kev_calibration.png")); plt.close(fig)
print(json.dumps(sev, indent=1)); print(json.dumps(kevres, indent=1))
