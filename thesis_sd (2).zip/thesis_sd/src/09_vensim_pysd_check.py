"""Stage 9 (structural cross-check): run the Vensim model vensim/vulnerability_sd_model.mdl with PySD and compare its
trajectories with the mean of 4,000 episodes of the item-level reference model (sdmodel.py, original parameters).
Requires PySD (pip install pysd) in a separate environment; not part of verify.sh."""
import json, os, sys
import numpy as np, pysd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sdmodel import ORIGINAL, simulate
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
model = pysd.read_vensim(os.path.join(ROOT, "vensim", "vulnerability_sd_model.mdl"))
v = model.run(return_columns=["Backlog", "Availability", "patching", "effective capacity", "exposure"])
o = simulate(dict(ORIGINAL), 4000, np.random.default_rng(20261007), record=True)
mc = {k: o["traj"][k].mean(1) for k in ("B", "A", "P")}
B_v, A_v, P_v = v["Backlog"].values[:15], v["Availability"].values[1:16], v["patching"].values[:15]
rel = lambda a, b: float(np.max(np.abs(a - b) / np.maximum(np.abs(b), 1e-9)))
out = {"vensim_backlog": B_v.tolist(), "reference_backlog_mean": mc["B"].tolist(),
       "vensim_availability": A_v.tolist(), "reference_availability_mean": mc["A"].tolist(),
       "vensim_patches": P_v.tolist(), "reference_patches_mean": mc["P"].tolist(),
       "max_relative_difference": {"backlog": rel(B_v, mc["B"]), "availability": rel(A_v, mc["A"]), "patches_total": abs(P_v.sum() - mc["P"].sum()) / mc["P"].sum()},
       "pysd_version": pysd.__version__}
json.dump(out, open(os.path.join(ROOT, "results", "vensim_pysd_check.json"), "w"), indent=1)
print(json.dumps(out["max_relative_difference"], indent=1))
print("day  backlog V/ref   availability V/ref   patches V/ref")
for t in range(15): print(f"{t+1:3d}  {B_v[t]:6.2f}/{mc['B'][t]:6.2f}   {A_v[t]:.4f}/{mc['A'][t]:.4f}   {P_v[t]:4.1f}/{mc['P'][t]:4.2f}")
