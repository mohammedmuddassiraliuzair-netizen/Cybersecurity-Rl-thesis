"""Stage 5: RUN the calibrated SD model and COMPARE it with (i) the real data and (ii) the original
(pre-calibration) thesis parameterisation.

(a) Aggregate SD run driven by the ACTUAL NVD daily disclosure stream (scaled to the enterprise,
    phi = 3 / mean daily NVD count) with the calibrated two-stream remediation outflow.
(b) Effective remediation capacity c_cal of the item-level model found by differential evolution so
    that the simulated share of vulnerabilities remediated within 15 days of arrival matches the
    calibrated real-world value (Kenna/Cyentia curve, posterior mean).
(c) Monte Carlo comparison of three parameter sets on 15-day episodes, with Bayesian posterior
    uncertainty propagated by sampling calibrated parameters from their posteriors.
"""
import numpy as np, pandas as pd
from scipy.optimize import differential_evolution
from common import *
from sdmodel import ORIGINAL, calibrated, simulate
rng = np.random.default_rng(SEED)
ca = json.load(open(os.path.join(RES, "calibration_arrivals.json")))
cs = json.load(open(os.path.join(RES, "calibration_severity_kev.json")))
cr = json.load(open(os.path.join(RES, "calibration_remediation.json")))
arr_chain = np.load(os.path.join(RES, "arrival_posterior.npy"))
kev_chain = np.load(os.path.join(RES, "kev_posterior.npy"))

# ---- (a) aggregate SD with the actual disclosure stream ----------------------------------------
n = pd.read_csv(os.path.join(DATA, "nvd_2026_window.csv")); n = n[n.vulnStatus != "Rejected"]
days = pd.date_range("2026-06-17", "2026-10-06")
y = n.groupby("published").size().reindex(days.strftime("%Y-%m-%d"), fill_value=0).values.astype(float)
phi = 3.0 / ca["data"]["cal_mean_per_day"]
res_all = cr["all_vulnerabilities"]["DE"]; res_ke = cr["known_exploit"]["DE"]
def aggregate(f, tf, ts, inflow, B0=8.0):
    Bf, Bs = B0 * f, B0 * (1 - f); out = []
    for N in inflow:                                   # Euler, dt = 1 day
        Pf, Ps = Bf / tf, Bs / ts
        Bf += f * N - Pf; Bs += (1 - f) * N - Ps; out.append((Bf + Bs, Pf + Ps))
    return np.array(out)
agg = aggregate(res_all["f_fast"], res_all["tau_fast_days"], res_all["tau_slow_days"], phi * y)
agg_ke = aggregate(res_ke["f_fast"], res_ke["tau_fast_days"], res_ke["tau_slow_days"], phi * y)
steady = 3.0 * res_all["mean_lifetime_days"]

# ---- (b) DE calibration of effective item-level capacity --------------------------------------
target_all = cr["all_vulnerabilities"]["Bayes"]["closed_within_15_days"]["mean"]
target_ke = cr["known_exploit"]["Bayes"]["closed_within_15_days"]["mean"]
pcal = calibrated(ca, cs)
def frac15(cap, R=150, Hlong=105, seed=7):
    p = dict(pcal, cap=float(cap), H=Hlong)
    r = np.random.default_rng(seed)                     # common random numbers across DE evaluations
    o = simulate(p, R, r, policy="sd", nmax=420, record=False, return_items=True)
    born, done = o["born"], o["done_t"]
    coh = (born >= 20) & (born <= Hlong - 15)
    return float(((done >= 0) & (done - born < 15) & coh).sum() / coh.sum())
de_all = differential_evolution(lambda c: (frac15(c[0]) - target_all) ** 2, [(0.5, 4.0)], seed=SEED, popsize=8, maxiter=12, tol=1e-8, polish=False)
de_ke = differential_evolution(lambda c: (frac15(c[0]) - target_ke) ** 2, [(0.5, 4.0)], seed=SEED, popsize=8, maxiter=12, tol=1e-8, polish=False)
c_cal, c_ke = float(de_all.x[0]), float(de_ke.x[0])
check = {"orig_cap4_frac15": frac15(4.0), "c_cal_frac15": frac15(c_cal), "c_ke_frac15": frac15(c_ke)}

# ---- (c) Monte Carlo comparison with posterior propagation ------------------------------------
def post_params(i, cap):
    th = arr_chain[i % len(arr_chain)]
    s = np.r_[th[2:8], 0.0]; f = np.exp(s - s.mean()); f /= f.mean()
    k = np.exp(th[-1]); lpi, ltau = kev_chain[i % len(kev_chain)]
    share = rng.dirichlet(1 + np.array(cs["severity"]["counts_crit_high_medlow_missing"]))
    share = np.array([share[0], share[1] + share[3], share[2]])
    return dict(pcal, nb_k=float(k), dow=f, trend=float(th[1] / 90), share=tuple(share),
                eta=float(np.exp(lpi) / np.exp(ltau)), cap=cap)
metrics = ["exposure", "B_end", "delay", "unresolved", "avail_loss", "patches", "reward"]
scen = {}
idx = rng.choice(len(arr_chain), 300, replace=False)
for name, maker in [("Original (thesis Table X)", lambda i: dict(ORIGINAL)),
                    ("Calibrated, thesis capacity c = 4", lambda i: post_params(i, 4.0)),
                    (f"Calibrated, real-world capacity c = {c_cal:.2f}", lambda i: post_params(i, c_cal))]:
    vals = {m: [] for m in metrics}; trajs = []
    for i in idx:
        o = simulate(maker(i), 20, rng, policy="sd", record=True)
        for m in metrics: vals[m].append(o[m].mean())
        trajs.append({k: v.mean(1) for k, v in o["traj"].items()})
    scen[name] = {"summary": {m: {"mean": float(np.mean(v)), "q025": float(np.percentile(v, 2.5)), "q975": float(np.percentile(v, 97.5))} for m, v in vals.items()},
                  "traj": {k: np.array([t[k] for t in trajs]) for k in ("B", "E", "A")}}
out = {"phi_enterprise_scaling": phi,
       "aggregate_actual_stream": {"B_end_all": float(agg[-1, 0]), "B_end_known_exploit": float(agg_ke[-1, 0]),
                                   "steady_state_backlog_all": steady, "steady_state_backlog_known_exploit": 3.0 * res_ke["mean_lifetime_days"],
                                   "mean_outflow_last30_all": float(agg[-30:, 1].mean())},
       "capacity_DE": {"target_frac15_all": target_all, "target_frac15_known_exploit": target_ke,
                       "c_cal_all": c_cal, "c_cal_known_exploit": c_ke, "nfev": int(de_all.nfev + de_ke.nfev), "check": check},
       "scenarios": {k: v["summary"] for k, v in scen.items()}}
save_json(out, "run_and_compare.json")

# ---- Figures ----------------------------------------------------------------------------------
fig, ax = plt.subplots(2, 1, figsize=(6.5, 7.6))
ax[0].vlines(days, 0, phi * y, color=INK, lw=0.6, label="Actual NVD inflow, enterprise-scaled")
ax0 = ax[0].twinx(); ax0.spines["right"].set_visible(True); ax0.grid(False)
ax0.plot(days, agg[:, 0], color=C1, lw=1.6, label="Backlog B(t), all vulnerabilities")
ax0.plot(days, agg_ke[:, 0], color=C6, lw=1.6, ls="--", label="Backlog B(t), known-exploit calibration")
ax[0].set_ylabel("Arrivals per day"); ax0.set_ylabel("Open vulnerabilities (stock)")
h1, l1 = ax[0].get_legend_handles_labels(); h2, l2 = ax0.get_legend_handles_labels()
ax[0].legend(h1 + h2, l1 + l2, fontsize=8.5, loc="upper left"); ax[0].tick_params(axis="x", rotation=45, labelsize=8.5)
ax[0].set_title("(a) Calibrated aggregate SD driven by actual NVD stream", fontsize=9.5)
styles = [("-.", "o"), ("-", "s"), ("--", "^")]
for (name, v), (ls_, mk_) in zip(scen.items(), styles):
    tr = v["traj"]["B"]; tt = np.arange(1, tr.shape[1] + 1)
    for q_ in np.percentile(tr, [5, 95], 0): ax[1].plot(tt, q_, color=INK, lw=0.5, ls=ls_)
    ax[1].plot(tt, tr.mean(0), color=INK, lw=1.6, ls=ls_, marker=mk_, mfc="white", ms=3.5, label=name)
ax[1].set_xlabel("Episode day"); ax[1].set_ylabel("Open vulnerabilities B(t)")
ax[1].set_title("(b) Item-level SD episodes: original vs calibrated", fontsize=9.5); ax[1].legend(fontsize=8.5)
fig.tight_layout(); fig.savefig(os.path.join(FIGS, "fig10_run_compare.png")); plt.close(fig)
print(json.dumps({k: out[k] for k in ("phi_enterprise_scaling", "aggregate_actual_stream", "capacity_DE")}, indent=1))
for k, v in out["scenarios"].items(): print(k, {m: round(s["mean"], 3) for m, s in v.items()})
