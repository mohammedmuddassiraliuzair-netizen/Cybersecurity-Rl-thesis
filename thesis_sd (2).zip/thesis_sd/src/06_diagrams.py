"""Stage 6: causal loop diagram (CLD) and stock-and-flow diagram (SFD) of the SD model."""
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Polygon
from common import *

def node(ax, xy, text, size=10.5, color=INK, weight="normal", style="normal"):
    ax.text(*xy, text, ha="center", va="center", fontsize=size, color=color, weight=weight, style=style,
            bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none"), zorder=5)

def link(ax, a, b, sign, rad=0.0, style="-", color=MUTED, frac=0.9, shrink=30, off=0.2):
    ar = FancyArrowPatch(a, b, connectionstyle=f"arc3,rad={rad}", arrowstyle="-|>", mutation_scale=12,
                         lw=1.3, ls=style, color=color, shrinkA=shrink, shrinkB=shrink, zorder=2)
    ax.add_patch(ar)
    # polarity sign placed near the arrow head, offset to the left of travel direction
    a, b = np.array(a, float), np.array(b, float); m = (a + b) / 2; d = b - a
    nrm = np.array([-d[1], d[0]]) / (np.linalg.norm(d) + 1e-9)
    ctrl = m + rad * np.array([d[1], -d[0]])               # control point exactly as matplotlib arc3
    bez = lambda t: (1 - t) ** 2 * a + 2 * (1 - t) * t * ctrl + t ** 2 * b
    ts = np.linspace(0, 1, 400); dist = np.array([np.linalg.norm(bez(x) - b) for x in ts])
    t = ts[np.argmin(np.abs(dist - frac))]
    pt = bez(t)
    tan = 2 * (1 - t) * (ctrl - a) + 2 * t * (b - ctrl); tn = np.array([-tan[1], tan[0]]) / np.linalg.norm(tan)
    ax.text(*(pt + tn * off), sign, ha="center", va="center", fontsize=10, color=C6, weight="bold", zorder=6)

def loop(ax, xy, label, sub, color=C1):
    ax.text(xy[0], xy[1] + 0.05, label, ha="center", va="center", fontsize=9.5, color=color, weight="bold", zorder=4)
    ax.text(xy[0], xy[1] - 0.27, sub, ha="center", va="center", fontsize=8.5, color=color, zorder=4)
    ax.add_patch(FancyArrowPatch((xy[0] + 0.42, xy[1] + 0.22), (xy[0] + 0.42, xy[1] - 0.06), connectionstyle="arc3,rad=-1.4",
                                 arrowstyle="-|>", mutation_scale=8, color=color, lw=1.0, zorder=4))

# ---------------- CLD (drawn at printed size, 6.5 in wide) ----------------
P = {"B": (-2.65, 0.5), "E": (0, 2.15), "PRI": (2.9, 0.5), "P": (0, -1.0), "D": (2.9, -2.35), "A": (0, -3.65),
     "REC": (-3.1, -3.9), "CAP": (-2.9, -2.05), "DISC": (-5.15, 1.85), "THR": (2.75, 3.25), "W": (-2.75, 3.25),
     "MNT": (-5.15, -2.75), "DEL": (-5.45, -0.3), "EMG": (-4.75, -1.05)}
fig, ax = plt.subplots(figsize=(6.5, 6.0)); ax.set_xlim(-6.3, 5.9); ax.set_ylim(-4.6, 3.75); ax.axis("off")
link(ax, P["B"], P["E"], "+", rad=-0.25, frac=1.35); link(ax, P["E"], P["PRI"], "+", rad=-0.25); link(ax, P["PRI"], P["P"], "+", rad=-0.25, frac=1.3)
link(ax, P["P"], P["B"], "−", rad=-0.25); link(ax, P["B"], P["PRI"], "+", rad=0.0, frac=1.3)
link(ax, P["P"], P["D"], "+", rad=0.2); link(ax, P["E"], P["D"], "+", rad=-0.95)
link(ax, P["D"], P["PRI"], "−", rad=0.25, style="--", off=-0.2)
link(ax, P["D"], P["A"], "−", rad=-0.2, frac=1.4); link(ax, P["A"], P["REC"], "−", rad=-0.45); link(ax, P["REC"], P["A"], "+", rad=-0.45)
link(ax, P["CAP"], P["P"], "+", rad=0.15); link(ax, P["A"], P["CAP"], "+", rad=-0.25)
link(ax, P["B"], P["EMG"], "+", rad=0.0, frac=0.9); link(ax, P["EMG"], P["CAP"], "−", rad=0.0, frac=0.9)
link(ax, P["DISC"], P["B"], "+"); link(ax, P["THR"], P["E"], "+", frac=1.5); link(ax, P["W"], P["E"], "+", frac=1.5)
link(ax, P["MNT"], P["CAP"], "−", frac=1.1); link(ax, P["B"], P["DEL"], "+", frac=0.7)
for k, t, sz, c, w in [("B", "Open\nvulnerabilities B", 9.5, INK, "bold"), ("E", "Exposure E", 9.5, INK, "bold"),
                       ("PRI", "Remediation\npriority", 9, INK, "normal"), ("P", "Patch rate P", 9.5, INK, "bold"),
                       ("D", "Service\ndisruption D", 9, INK, "normal"), ("A", "Availability A", 9.5, INK, "bold"),
                       ("REC", "Availability\nrecovery", 9, INK, "normal"), ("CAP", "Effective\ncapacity c", 9, INK, "normal"),
                       ("DISC", "Disclosures\n(NVD)", 8.5, MUTED, "normal"), ("THR", "Threat signals\n(EPSS, KEV)", 8.5, MUTED, "normal"),
                       ("W", "Asset\nweights w", 8.5, MUTED, "normal"), ("MNT", "Maintenance\nclosures", 8.5, MUTED, "normal"),
                       ("DEL", "Remediation\ndelay", 8.5, MUTED, "normal"), ("EMG", "Emergency\nwork f", 9, INK, "normal")]:
    node(ax, P[k], t, sz, c, w, "italic" if k in ("DISC", "THR", "W", "MNT") else "normal")
loop(ax, (0.15, 1.05), "B1", "remediation"); loop(ax, (-0.4, -0.05), "B2", "backlog\nclearing")
loop(ax, (2.3, -1.05), "B3", "anticipated\ndisruption"); loop(ax, (-1.55, -4.15), "B4", "recovery")
loop(ax, (0.1, -2.3), "B5", "capacity\nthrottling"); loop(ax, (-2.55, -0.75), "R1", "emergency\nwork", color=C2)
fig.savefig(os.path.join(FIGS, "fig11_causal_loop_diagram.png")); plt.close(fig)

# ---------------- SFD (drawn at printed size; coordinates in inches) ----------------
fig, ax = plt.subplots(figsize=(6.5, 4.9)); ax.set_xlim(0, 6.5); ax.set_ylim(0, 4.9); ax.axis("off")
def stock(x, y, w, h, title, sub):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="square,pad=0", fc="white", ec=INK, lw=1.5, zorder=3))
    ax.text(x, y + 0.13, title, ha="center", va="center", fontsize=10, weight="bold", zorder=4)
    ax.text(x, y - 0.17, sub, ha="center", va="center", fontsize=8.5, zorder=4)
def cloud(x, y, lab):
    for dx, dy, r in [(-0.08, 0, .08), (0.03, .045, .095), (0.11, -0.012, .075), (0.012, -0.05, .075)]:
        ax.add_patch(Circle((x + dx, y + dy), r, fc="white", ec=MUTED, lw=0.9, zorder=3))
    ax.add_patch(Circle((x + 0.02, y), 0.08, fc="white", ec="none", zorder=4))
    ax.text(x + 0.02, y + 0.17, lab, ha="center", va="bottom", fontsize=8.5, color=MUTED)
def pipe(x0, x1, y, vx, label, pos="below"):
    ax.add_patch(FancyArrowPatch((x0, y), (x1, y), arrowstyle="-|>", mutation_scale=14, lw=3.2, color=INK, zorder=2))
    ax.add_patch(Polygon([[vx - .09, y + .11], [vx + .09, y + .11], [vx - .09, y - .11], [vx + .09, y - .11]], closed=True, fc="white", ec=INK, lw=1.1, zorder=4))
    if pos == "above": ax.text(vx, y + 0.2, label, ha="center", va="bottom", fontsize=8.5, zorder=5)
    elif pos == "below-right": ax.text(vx + 0.13, y - 0.18, label, ha="left", va="top", fontsize=8.5, zorder=5)
    else: ax.text(vx, y - 0.2, label, ha="center", va="top", fontsize=8.5, zorder=5)
def info(a, b, rad, lab=None, lxy=None, ha="center"):
    ax.add_patch(FancyArrowPatch(a, b, connectionstyle=f"arc3,rad={rad}", arrowstyle="-|>", mutation_scale=9, lw=0.9, ls="--", color=MUTED, zorder=1))
    if lab: ax.text(*lxy, lab, ha=ha, va="center", fontsize=8, color=MUTED, style="italic")
yb, ya = 3.95, 1.95
cloud(0.3, yb, "Disclosures\n(NVD)"); pipe(0.45, 2.02, yb, 1.25, "Arrivals N(t)"); stock(3.1, yb, 2.15, 0.72, "Backlog B(t)", "three FIFO severity queues")
pipe(4.18, 5.8, yb, 4.95, "Patches P(t)\n≤ capacity c(t)", pos="above"); cloud(6.12, yb, "Remediated")
cloud(0.3, ya, "Source"); pipe(0.45, 2.02, ya, 1.25, "Recovery\nα(1 − A)"); stock(3.1, ya, 2.15, 0.72, "Availability A(t)", "between 0.6 and 1")
pipe(4.18, 5.8, ya, 4.95, "Disruption D(t)\nβ1 P + β2 E", pos="below-right"); cloud(6.12, ya, "Sink")
ax.text(3.1, 0.42, "Exposure E(t)\nthreat-weighted open items", ha="center", va="center", fontsize=8.5, style="italic",
        bbox=dict(boxstyle="round,pad=0.3", fc="white", ec=MUTED, ls="--"), zorder=3)
info((2.35, yb - 0.37), (2.2, 0.62), 0.35, "backlog sets\nexposure", (1.25, 1.05))
info((3.98, 0.42), (4.89, ya - 0.13), 0.3, "exposure pressure", (5.15, 0.85), ha="left")
info((4.95, yb - 0.13), (4.95, ya + 0.13), 0.0, "patches cause\ndisruption", (5.07, 2.95), ha="left")
info((3.9, ya + 0.37), (4.85, yb - 0.11), -0.25, "availability and\nbacklog set capacity", (3.3, 2.95), ha="center")
fig.savefig(os.path.join(FIGS, "fig12_stock_flow_diagram.png")); plt.close(fig)
print("diagrams written")

# ---------------- Figure 1: conceptual architecture (monochrome, drawn at printed size) ----------------
fig, ax = plt.subplots(figsize=(6.5, 7.6)); ax.set_xlim(0, 6.5); ax.set_ylim(0, 7.6); ax.axis("off")
def box(x, y, w, h, title, body, lw=1.1):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.06", fc="white", ec=INK, lw=lw, zorder=2))
    ax.text(x + w / 2, y + h - 0.13, title, ha="center", va="top", fontsize=9.5, weight="bold", color=INK, zorder=3)
    ax.text(x + w / 2, y + h - 0.45, body, ha="center", va="top", fontsize=8.8, color=INK, linespacing=1.3, zorder=3)
def down(y0, y1): ax.add_patch(FancyArrowPatch((3.25, y0), (3.25, y1), arrowstyle="-|>", mutation_scale=13, lw=1.3, color=INK))
def band(y, t): ax.text(0.05, y, t, ha="left", va="center", fontsize=9, weight="bold", color=MUTED)
band(7.47, "1  PUBLIC DATA, AS KNOWN ON EACH DAY")
box(0.05, 6.1, 2.05, 1.15, "NVD / CVSS 3.1", "32,476 CVEs published\nJun 17 – Sep 14, 2026")
box(2.225, 6.1, 2.05, 1.15, "EPSS daily scores", "file of the previous day\n(one-day lag)")
box(4.4, 6.1, 2.05, 1.15, "CISA KEV catalog", "version in force on\neach decision day")
down(6.05, 5.72); band(5.58, "2  SYSTEM DYNAMICS MODEL")
box(0.05, 4.3, 6.4, 1.12, "Two stocks: backlog B and availability A", "capacity limited by availability and by emergency work\ncalibrated by differential evolution and Bayesian MCMC (Chapter IV)", lw=1.6)
down(4.25, 3.92); band(3.78, "3  POLICIES COMPARED")
box(0.05, 2.3, 3.12, 1.3, "Rule-based", "B1 CVSS-First     B2 EPSS-First\nB3 KEV-First       B4 SD-Only")
box(3.33, 2.3, 3.12, 1.3, "Learned (PPO, 30 seeds each)", "M1 Model-Free\nM2 Residual (proposed)\nM2-P Placebo residual")
down(2.25, 1.92); band(1.78, "4  EVALUATION DESIGN")
box(0.05, 0.05, 2.05, 1.55, "Training", "Jun 18 – Aug 1, 2026\n90 agents ×\n9,600 transitions")
box(2.225, 0.05, 2.05, 1.55, "Validation", "Aug 2 – 16, 2026\nlearning curves\nonly (E3)")
box(4.4, 0.05, 2.05, 1.55, "Test, policies frozen", "Sep 16 – Oct 1, 2026\nnominal + 4 stresses\nexperiments E1 and E2", lw=1.6)
fig.savefig(os.path.join(FIGS, "fig0_architecture.png")); plt.close(fig)
print("architecture figure written")
