#!/usr/bin/env bash
# Reproduce every calibration, sensitivity and Pareto result and figure in Appendices C-F.
# Stage 1 needs a local snapshot of https://github.com/fkie-cad/nvd-json-data-feeds (CVE-2025, CVE-2026 folders);
# its output data/nvd_2026_window.csv is shipped, so stages 2-8 run from the shipped data alone.
set -euo pipefail
# Math libraries pinned to the AVX2 code path for bit-for-bit reproducibility on any x86-64 AVX2 computer.
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 OPENBLAS_CORETYPE=Haswell
export NPY_DISABLE_CPU_FEATURES="AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL,AVX512_SPR"
cd "$(dirname "$0")/src"
mkdir -p ../results ../figs
if [ -n "${NVD_FEED_DIR:-}" ]; then python3 01_extract_nvd.py "$NVD_FEED_DIR" ../data/nvd_2026_window.csv; fi
for s in 02_calibrate_arrivals 03_calibrate_severity_kev 04_calibrate_remediation 05_run_and_compare 06_diagrams 07_sobol 08_pareto; do
  echo "== $s"; python3 "$s.py"
done
sha256sum ../data/* ../results/*.json > ../results/SHA256SUMS.txt
echo; echo "Pipeline finished. Run ./verify.sh to compare against the thesis reference results."
