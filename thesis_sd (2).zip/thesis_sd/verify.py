"""Compare a fresh run (results/) with the reference results used in the thesis (reference/).
Step 1: exact check of SHA-256 checksums.  Step 2 (only if checksums differ, e.g. different CPU type):
every number in every results file is compared with the reference; differences larger than a relative
tolerance of 1e-6 are listed."""
import json, os, sys, hashlib
ROOT = os.path.dirname(os.path.abspath(__file__))
FILES = ["calibration_arrivals.json", "calibration_severity_kev.json", "calibration_remediation.json",
         "run_and_compare.json", "sobol_indices.json", "pareto.json"]
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
exact = all(sha(os.path.join(ROOT, "results", f)) == sha(os.path.join(ROOT, "reference", f)) for f in FILES)
if exact:
    print("PASS: all 6 result files are byte-for-byte identical to the thesis reference results."); sys.exit(0)
def walk(a, b, path, out):
    if isinstance(a, dict):
        for k in a: walk(a[k], b.get(k) if isinstance(b, dict) else None, f"{path}.{k}", out)
    elif isinstance(a, list):
        for i, x in enumerate(a): walk(x, b[i] if isinstance(b, list) and i < len(b) else None, f"{path}[{i}]", out)
    elif isinstance(a, (int, float)) and not isinstance(a, bool):
        if not isinstance(b, (int, float)) or abs(a - b) > 1e-6 * max(1.0, abs(a)): out.append((path, a, b))
    elif a != b: out.append((path, a, b))
bad = []
for f in FILES:
    walk(json.load(open(os.path.join(ROOT, "reference", f))), json.load(open(os.path.join(ROOT, "results", f))), f, bad)
if not bad:
    print("PASS (numerical): checksums differ only in the last floating-point digits; every number agrees "
          "with the reference to within 1e-6 relative."); sys.exit(0)
print(f"FAIL: {len(bad)} numbers differ from the reference. First 25 (path, reference, this run):")
for b in bad[:25]: print("  ", *b)
print("Check that the package versions in requirements.txt are installed exactly."); sys.exit(1)
