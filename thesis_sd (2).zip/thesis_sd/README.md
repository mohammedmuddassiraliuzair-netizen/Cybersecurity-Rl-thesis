# thesis_sd (v4, revised capacity rule and reward) — System Dynamics calibration, sensitivity and Pareto package

Companion code for *Reinforcement Learning and Agentic AI in Cybersecurity: A Trade-off Analysis*
(M. M. A. Uzair, Cleveland State University, 2026), Chapters IV and VI and Appendices B–F.

## For reviewers: reproduce and verify in three commands
    pip install -r requirements.txt     # exact versions; use a fresh virtual environment
    ./run_all.sh                         # about 10-25 minutes depending on the computer
    ./verify.sh                          # compares your results with the thesis reference results

`verify.sh` prints **PASS** when every result matches the numbers reported in the thesis.
All random number generators, including the MCMC samplers, are seeded with the master seed
20261007, so repeated runs on the same software versions produce byte-for-byte identical results.
On a different CPU type the last floating-point digits can differ; `verify.sh` then checks every
number to a relative tolerance of 1e-6 and reports any difference.

Tested on Python 3.12 with the versions in `requirements.txt`; two independent full runs
produced identical SHA-256 checksums for every result file and every figure.

Stage 1 (`src/01_extract_nvd.py`) needs a local copy of https://github.com/fkie-cad/nvd-json-data-feeds
(folders CVE-2025 and CVE-2026); set `NVD_FEED_DIR=/path/to/feed` to run it. Its output
`data/nvd_2026_window.csv` is included, so all later stages run from the shipped data.

## Exact reproduction
run_all.sh pins the math libraries to the AVX2 code path (OPENBLAS_CORETYPE=Haswell, NumPy AVX-512 dispatch disabled)
and runs single-threaded, so ./verify.sh reports byte-for-byte identical results on any x86-64 computer with AVX2.
The Dockerfile reproduces the exact software stack:
    docker build --platform linux/amd64 -t thesis-sd .
    docker run --rm --platform linux/amd64 thesis-sd bash -c "./run_all.sh && ./verify.sh"

## Vensim model (structural cross-check)
vensim/vulnerability_sd_model.mdl is the System Dynamics structure as a Vensim model (opens in Vensim PLE).
src/09_vensim_pysd_check.py runs it with PySD (pip install pysd, in a separate environment) and compares it with
the mean of 4,000 reference-model episodes (Table F4). This check is not part of verify.sh.

## Layout
| Path | Contents |
|---|---|
| `data/nvd_2026_window.csv` | NVD records published Jun 1 – Oct 7 2026 (id, date, status, CVSS 3.1) from snapshot commit 641cce51 |
| `data/kev_catalog.json` | CISA KEV catalog v2026.10.04 (github.com/cisagov/kev-data) |
| `data/remediation_literature.csv` | Published remediation milestones (Kenna Security & Cyentia Institute, 2019); 9 rows, of which stage 4 uses the 6 for all vulnerabilities and known-exploit vulnerabilities |
| `src/sdmodel.py` | Reference SD model (Appendix B, Eqs. B1–B13, B18–B20) |
| `src/02`–`04` | Calibration: arrivals (DE + Bayesian NB), severity & KEV escalation, remediation outflow |
| `src/05_run_and_compare.py` | Capacity calibration (DE), calibrated run vs original parameters |
| `src/06_diagrams.py` | Causal loop diagram and stock-and-flow diagram |
| `src/07_sobol.py` / `src/08_pareto.py` | Sobol global sensitivity; Pareto frontiers |
| `tools/inject_equations.py` | Converts LaTeX equations to native Word (OMML) equations via pandoc |
| `results/` | Numeric outputs of the most recent run |
| `reference/` | The results used in the thesis tables, with `REFERENCE_SHA256SUMS.txt` |
| `figs/` | All new thesis figures |

Note: stage 8 part (B) checks Pareto dominance among the six RL policy arms using the values
reported in Tables XV–XVI, which are produced by the separate RL experiment code, not by this package.

Figure file → thesis figure: fig11_causal_loop_diagram → Fig. 2, fig12_stock_flow_diagram → Fig. 3,
fig7 → Fig. 4, fig8 → Fig. 5, fig9 → Fig. 6, fig10 → Fig. 7, fig6_sobol_sensitivity → Fig. 11,
fig13 → Fig. 13, fig14 → Fig. 14.
