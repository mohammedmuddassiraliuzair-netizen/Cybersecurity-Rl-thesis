"""Replace equation placeholders (§EQn§) in a DOCX with native Word (OMML) equations.

Each equation is written in LaTeX (equations.json, produced by the thesis build script). Pandoc
converts the LaTeX to Office Math Markup Language exactly as Word's own equation editor (Alt+=) stores
it, so every equation in the thesis is an editable Word equation object, not an image or plain text.
Usage: python3 inject_equations.py thesis.docx equations.json out.docx
"""
import json, re, subprocess, sys, tempfile, zipfile, os, shutil

src, eq_json, out = sys.argv[1:4]
eqs = json.load(open(eq_json))
tmp = tempfile.mkdtemp()
md = os.path.join(tmp, "eqs.md")
with open(md, "w") as f:
    for i, latex in enumerate(eqs):
        f.write(f"EQSTART{i} ${latex}$\n\n")
subprocess.run(["pandoc", md, "-f", "markdown+tex_math_dollars", "-o", os.path.join(tmp, "eqs.docx")], check=True)
pxml = zipfile.ZipFile(os.path.join(tmp, "eqs.docx")).read("word/document.xml").decode("utf8")

RPR = '<w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math"/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr>'
def style_runs(omath):
    # give every math run 12-pt Cambria Math so equations match the 12-pt body text
    omath = re.sub(r"<m:r>((?:<m:rPr>(?:(?!</m:rPr>).)*</m:rPr>)?)", lambda m: "<m:r>" + m.group(1) + RPR, omath, flags=re.S)
    # reorder pandoc's property elements into the order required by the OMML schema (ECMA-376)
    omath = re.sub(r"<m:dPr>(<m:begChr[^>]*/>)(<m:endChr[^>]*/>)(<m:sepChr[^>]*/>)", r"<m:dPr>\1\3\2", omath)
    omath = re.sub(r"(<m:sty [^>]*/>)(<m:scr [^>]*/>)", r"\2\1", omath)
    omath = re.sub(r"<m:nor />\s*<m:sty [^>]*/>", "<m:nor />", omath)
    omath = re.sub(r"(<m:mcJc [^>]*/>)(<m:count [^>]*/>)", r"\2\1", omath)
    return omath

omml = {}
for para in re.findall(r"<w:p>.*?</w:p>|<w:p .*?</w:p>", pxml, flags=re.S):
    m = re.search(r"EQSTART(\d+)", para)
    if not m: continue
    maths = re.findall(r"<m:oMath>.*?</m:oMath>", para, flags=re.S)
    if len(maths) != 1: raise SystemExit(f"equation {m.group(1)}: pandoc produced {len(maths)} math objects: {eqs[int(m.group(1))]}")
    omml[int(m.group(1))] = style_runs(maths[0])
missing = [i for i in range(len(eqs)) if i not in omml]
if missing: raise SystemExit(f"pandoc failed to convert equations {missing}")

zin = zipfile.ZipFile(src); doc = zin.read("word/document.xml").decode("utf8")
run_pat = re.compile(r"<w:r>(?:(?!</w:r>).)*?§EQ(\d+)§</w:t></w:r>", flags=re.S)
count = 0
def repl(mo):
    global count; count += 1
    return omml[int(mo.group(1))]
doc = run_pat.sub(repl, doc)
left = re.findall(r"§EQ\d+§", doc)
if left: raise SystemExit(f"unreplaced placeholders: {left[:5]}")
zout = zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED)
for item in zin.infolist():
    data = doc.encode("utf8") if item.filename == "word/document.xml" else zin.read(item.filename)
    zout.writestr(item, data)
zout.close(); shutil.rmtree(tmp)
print(f"{count} equation placeholders replaced with native Word equations ({len(eqs)} distinct)")
