#!/usr/bin/env bash
# Full study. Single-threaded, with the math libraries pinned to the AVX2 code path so that results are
# bit-for-bit identical on any x86-64 computer with AVX2 (Intel/AMD since about 2013); see Dockerfile.
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_CORETYPE=Haswell
export NPY_DISABLE_CPU_FEATURES="AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL,AVX512_SPR"
export OUT="${OUT:-results}"
python3 run_study.py scales
python3 run_study.py twin
python3 run_study.py e2
python3 run_study.py e3
VARIANT=balanced python3 run_study.py twin
python3 analysis.py > /dev/null
python3 analysis_balanced.py > /dev/null
echo "STUDY COMPLETE in $OUT"
