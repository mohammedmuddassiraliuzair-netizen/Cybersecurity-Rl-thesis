"""EXPLORATORY (not pre-registered): balanced reward lambda = mu = 1. Compares with the pre-registered study."""
import os, json, sys
import numpy as np, pandas as pd
from scipy.stats import wilcoxon
ROOT = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, ROOT)
os.environ["VARIANT"] = "balanced"; import run_study as R
from hybrid_vm.env import Episode
out = {}
O = os.environ.get("OUT", "results")
for lab, d in (("preregistered", O), ("balanced", O + "_balanced")):
    T = pd.read_csv(os.path.join(ROOT, d, "twin", "test_results.csv"))
    sm = T.groupby(["condition", "arm", "seed"], as_index=False).exposure_index.mean()
    out[lab] = sm.groupby(["condition", "arm"]).exposure_index.mean().unstack("condition")[["normal", "threat", "resource", "asset", "joint"]]
    n = sm[sm.condition == "normal"]; J = {a: n[n.arm == a].set_index("seed").exposure_index for a in ("M1", "M2P", "M2")}
    out[lab + "_tests"] = {"M2_vs_M2P_p": float(wilcoxon(J["M2"] - J["M2P"], alternative="less").pvalue), "M2_wins_vs_M2P": int((J["M2"] < J["M2P"]).sum()),
                           "M2_vs_M1_p": float(wilcoxon(J["M2"] - J["M1"], alternative="less").pvalue), "M2_wins_vs_M1": int((J["M2"] < J["M1"]).sum())}
S = R.load_scales(); tot = np.zeros(3)
for s in R.TEST_TRACES:
    ep = Episode(R.PANEL, s, 90, "normal", "revised", S)
    while ep.t < 15: ep.step(R.make_policy("B4", S)(ep))
    tot += np.array(ep.terms).sum(0)
share = (tot / tot.sum()).round(3).tolist()
pd.concat({k: out[k] for k in ("preregistered", "balanced")}).round(4).to_csv(os.path.join(ROOT, O + "_balanced", "comparison.csv"))
json.dump({"reward_share_exposure_backlog_availability": share, "tests": {k: out[k + "_tests"] for k in ("preregistered", "balanced")}},
          open(os.path.join(ROOT, O + "_balanced", "exploratory_summary.json"), "w"), indent=1)
print("reward shares (exposure, backlog, availability):", share)
for k in ("preregistered", "balanced"): print("==", k); print(out[k].round(3).to_string()); print(out[k + "_tests"])
