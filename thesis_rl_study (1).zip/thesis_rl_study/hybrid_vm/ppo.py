"""PPO-Clip in NumPy with analytic gradients (thesis Chapter V, Table XIV settings).

Actor 96-32-35 and critic 96-32-1, one tanh hidden layer each, separate Adam optimisers.
Logits by arm:  M1  z = f(o)                 (model-free, unbounded)
                M2  z = z_SD(o) + 2 tanh f(o)  (residual on the SD prior)
                M2P z = 2 tanh f(o)            (placebo: zero prior, same bounded residual)
Infeasible actions are masked before the softmax. Training samples; evaluation takes the highest logit.
"""
import numpy as np
from .env import NA

GAMMA, LAM, CLIP, EPOCHS, MB = 0.99, 0.95, 0.2, 8, 128
LR_A, LR_C, ENT, TARGET_KL, GNORM = 3e-4, 1e-3, 0.01, 0.02, 0.5
OBS = 96


class Adam:
    def __init__(self, params, lr):
        self.p, self.lr, self.t = params, lr, 0
        self.m = [np.zeros_like(x) for x in params]; self.v = [np.zeros_like(x) for x in params]

    def step(self, grads):
        norm = np.sqrt(sum(float((g * g).sum()) for g in grads))          # global gradient-norm clip
        if norm > GNORM: grads = [g * (GNORM / norm) for g in grads]
        self.t += 1
        for x, g, m, v in zip(self.p, grads, self.m, self.v):
            m *= 0.9; m += 0.1 * g; v *= 0.999; v += 0.001 * g * g
            mh = m / (1 - 0.9 ** self.t); vh = v / (1 - 0.999 ** self.t)
            x -= self.lr * mh / (np.sqrt(vh) + 1e-8)


def _mlp(rng, out, out_scale):
    W0 = rng.normal(0, 1 / np.sqrt(OBS), (OBS, 32)); b0 = np.zeros(32)
    W1 = rng.normal(0, out_scale / np.sqrt(32), (32, out)); b1 = np.zeros(out)
    return [W0, b0, W1, b1]


class Agent:
    def __init__(self, arm, seed):
        assert arm in ("M1", "M2", "M2P")
        self.arm = arm
        rng = np.random.default_rng([seed, 0])
        self.actor = _mlp(rng, NA, 0.01)        # small output layer: M2 starts close to its prior
        self.critic = _mlp(rng, 1, 1.0)
        self.oa, self.oc = Adam(self.actor, LR_A), Adam(self.critic, LR_C)

    # ---- forward --------------------------------------------------------------------------------
    def logits(self, X, zsd, mask):
        W0, b0, W1, b1 = self.actor
        h = np.tanh(X @ W0 + b0); l = h @ W1 + b1
        if self.arm == "M1": z = l
        elif self.arm == "M2": z = zsd + 2 * np.tanh(l)
        else: z = 2 * np.tanh(l)
        z = np.where(mask, z, -1e9)
        return z, h, l

    @staticmethod
    def softmax(z):
        z = z - z.max(-1, keepdims=True); e = np.exp(z); return e / e.sum(-1, keepdims=True)

    def value(self, X):
        W0, b0, W1, b1 = self.critic
        h = np.tanh(X @ W0 + b0); return (h @ W1 + b1)[..., 0], h

    def act(self, obs, zsd, mask, rng=None):
        z, _, _ = self.logits(obs[None], zsd[None], mask[None])
        if rng is None: return int(np.argmax(z[0]))                      # evaluation: highest logit
        p = self.softmax(z)[0]; a = int(rng.choice(NA, p=p))
        return a, float(np.log(p[a] + 1e-300))

    def residual_magnitude(self, obs, zsd, mask):
        """R_t = ||2 tanh f(o)|| / (||z_SD|| + eps), over feasible actions (Revision C1.6)."""
        _, _, l = self.logits(obs[None], zsd[None], mask[None])
        r = 2 * np.tanh(l[0][mask]); zs = zsd[mask]
        return float(np.linalg.norm(r) / (np.linalg.norm(zs) + 1e-8))

    # ---- update -------------------------------------------------------------------------------------
    def update(self, B, rng):
        X, Z, M, A, LP, ADV, RET = B["obs"], B["zsd"], B["mask"], B["act"], B["logp"], B["adv"], B["ret"]
        N = len(A); stats = {"epochs": 0, "kl": 0.0}
        for ep in range(EPOCHS):
            idx = rng.permutation(N)
            for s in range(0, N, MB):
                j = idx[s:s + MB]; n = len(j)
                adv = ADV[j]; adv = (adv - adv.mean()) / (adv.std() + 1e-8)
                # actor
                W0, b0, W1, b1 = self.actor
                z, h, l = self.logits(X[j], Z[j], M[j]); p = self.softmax(z); logp_all = np.log(p + 1e-300)
                lp = logp_all[np.arange(n), A[j]]; ratio = np.exp(lp - LP[j])
                active = np.where(adv >= 0, ratio <= 1 + CLIP, ratio >= 1 - CLIP)
                g_lp = np.where(active, -adv * ratio, 0.0) / n                       # dL/dlogpi(a)
                onehot = np.zeros_like(p); onehot[np.arange(n), A[j]] = 1.0
                Hs = -(p * np.where(M[j], logp_all, 0.0)).sum(1)
                dH = -p * (np.where(M[j], logp_all, 0.0) + Hs[:, None])             # dH/dz
                dz = g_lp[:, None] * (onehot - p) - ENT * dH / n
                dz = np.where(M[j], dz, 0.0)
                dl = dz if self.arm == "M1" else dz * 2 * (1 - np.tanh(l) ** 2)
                dW1 = h.T @ dl; db1 = dl.sum(0); dpre = (dl @ W1.T) * (1 - h ** 2)
                self.oa.step([X[j].T @ dpre, dpre.sum(0), dW1, db1])
                # critic
                C0, c0, C1, c1 = self.critic
                v, hc = self.value(X[j]); dv = (v - RET[j])[:, None] / n
                dpc = (dv @ C1.T) * (1 - hc ** 2)
                self.oc.step([X[j].T @ dpc, dpc.sum(0), hc.T @ dv, dv.sum(0)])
            z, _, _ = self.logits(X, Z, M); lp_new = np.log(self.softmax(z)[np.arange(N), A] + 1e-300)
            kl = float(np.mean(LP - lp_new)); stats = {"epochs": ep + 1, "kl": kl}
            if kl > TARGET_KL: break
        return stats

    def params(self):
        return {f"actor_{i}": x for i, x in enumerate(self.actor)} | {f"critic_{i}": x for i, x in enumerate(self.critic)}


def gae(rewards, values):
    """Finite-horizon episode: terminal at the last step, bootstrap value 0."""
    T = len(rewards); adv = np.zeros(T); last = 0.0
    for t in reversed(range(T)):
        nv = values[t + 1] if t + 1 < T else 0.0
        delta = rewards[t] + GAMMA * nv - values[t]
        last = delta + GAMMA * LAM * last; adv[t] = last
    return adv, adv + np.asarray(values)
