"""Enterprise vulnerability-management environment (thesis Chapter IV, Equations 3-10 and B1-B17).

Two stocks: backlog B (three FIFO severity queues) and availability A, with real CVEs and their as-of
EPSS, KEV and CVSS values from the data panel.

Daily order:
  1. arrivals join their queues (Poisson(3) items drawn uniformly, with replacement, from eligible CVEs)
  2. each open item's EPSS updates to the as-of panel value (kept if the day has no score)
  3. availability updates from the previous day's patches and the current exposure
  4. capacity: c = min(4, floor(4 * A * r * (1 - f))), f = min(0.25, h * B / (B + 30)); 0 on days 7 and 14
  5. the policy patches a_k items from the head of queue k (FIFO)
  6. exposure E = sum over open items of min(1, h * p_i) * w_i is measured
The initial backlog of 8 items counts as arriving on day -1.
"""
import itertools
import numpy as np

ACTIONS = np.array([a for a in itertools.product(range(5), repeat=3) if sum(a) <= 4])   # 35 actions
NA = len(ACTIONS)
CONDITIONS = {"normal": (1.0, 1.0, 1.0), "threat": (2.0, 1.0, 1.0), "resource": (1.0, 0.6, 1.0),
              "asset": (1.0, 1.0, 2.0), "joint": (2.0, 0.6, 2.0)}          # (h, capacity factor r, asset multiplier)
H_DAYS, ALPHA, B1C, B2C, AMIN, CMAX = 15, 0.12, 0.004, 0.006, 0.6, 4
CVSS_IMPUTE = 7.3          # training-period median (preserved audit)


class Panel:
    """The preserved as-of panel: EPSS, CVSS 3.1 and KEV per decision day for the fixed cohort."""
    def __init__(self, path):
        z = np.load(path)
        self.ids, self.dates, self.pub = z["ids"], z["dates"], z["published"]
        self.epss, self.cvss, self.kev = z["epss"], z["cvss"], z["kev"]
        self.last = len(self.dates) - 1
        self._elig = {}

    def eligible(self, d):
        if d not in self._elig:
            self._elig[d] = np.flatnonzero((self.pub <= d) & ~np.isnan(self.epss[d]))
        return self._elig[d]


class Episode:
    """One 15-day enterprise episode on a fixed trace. reward_mode: 'original' (Chapter IV weights) or 'revised'."""
    def __init__(self, panel, trace_seed, start, condition="normal", reward_mode="original",
                 scales=None, h_env=None, w_scale_env=1.0):
        self.P = panel
        self.h, self.r, self.wm = CONDITIONS[condition]
        if h_env is not None: self.h = h_env              # E2B: environment threat scaling
        self.w_scale_env = w_scale_env                     # E2B: environment asset-weight scaling
        self.start, self.mode, self.scales = start, reward_mode, scales
        self.g = np.random.default_rng(trace_seed)
        self.c, self.w, self.q, self.arr, self.done, self.p, self.miss, self.kevf, self.sev = ([] for _ in range(9))
        self.t, self.A, self.Pprev = 0, 1.0, 0
        self.Es, self.Ds, self.ret, self.patched = [], [], 0.0, 0
        self.terms = []                                     # reward decomposition log
        self._add(8, -1)
        self._begin_day()

    # ---- trace -------------------------------------------------------------------------------
    def _day(self, t):
        return min(self.start + max(t, 0), self.P.last)

    def _add(self, n, t):
        d = self._day(t)
        e = self.P.eligible(d)
        idx = e[self.g.integers(0, len(e), n)]
        ws = self.g.uniform(0.5, 1.5, n)
        for ci, wi in zip(idx, ws):
            k = len(self.c)
            if self.wm != 1.0 and k % 3 == 2: wi *= self.wm
            wi *= self.w_scale_env
            cv = self.P.cvss[d, ci]; missing = bool(np.isnan(cv)); cv = CVSS_IMPUTE if missing else float(cv)
            self.c.append(ci); self.w.append(wi); self.q.append(0 if cv >= 9 else 1 if cv >= 7 else 2)
            self.arr.append(t); self.done.append(-1); self.p.append(float(self.P.epss[d, ci]))
            self.miss.append(missing); self.kevf.append(bool(self.P.kev[d, ci])); self.sev.append(cv); self.sev.append(cv)

    def _open(self):
        return [i for i in range(len(self.c)) if self.done[i] < 0]

    def exposure(self, h=None, w_scale=1.0, items=None):
        h = self.h if h is None else h
        items = self._open() if items is None else items
        return float(sum(min(1.0, h * self.p[i]) * self.w[i] * w_scale for i in items))

    def _begin_day(self):
        t = self.t
        n = int(self.g.poisson(3)); self._add(n, t)
        d = self._day(t)
        for i in self._open():
            v = self.P.epss[d, self.c[i]]
            if not np.isnan(v): self.p[i] = float(v)
            self.kevf[i] = bool(self.P.kev[d, self.c[i]])
        Epre = self.exposure()
        self.A = float(np.clip(self.A + ALPHA * (1 - self.A) - B1C * self.Pprev - B2C * Epre, AMIN, 1.0))
        B = len(self._open())
        f = min(0.25, self.h * B / (B + 30))
        maint = (t + 1) % 7 == 0
        self.cap = 0 if maint else min(CMAX, int(np.floor(CMAX * self.A * self.r * (1 - f))))
        self.queues = [[i for i in self._open() if self.q[i] == k] for k in range(3)]   # FIFO order
        for k in range(3): self.queues[k].sort(key=lambda i: (self.arr[i], i))

    # ---- interface -----------------------------------------------------------------------------
    def mask(self):
        lens = np.array([len(qk) for qk in self.queues])
        return (ACTIONS <= lens).all(1) & (ACTIONS.sum(1) <= self.cap)

    def step(self, a_idx):
        a = ACTIONS[a_idx]
        if not self.mask()[a_idx]: raise ValueError("infeasible action")
        P = 0
        for k in range(3):
            for i in self.queues[k][: a[k]]:
                self.done[i] = self.t; P += 1
        E = self.exposure(); B1 = len(self._open())
        D = B1C * P + B2C * E
        if self.mode == "original":
            r = -(0.5 * E + 0.03 * B1 + 4 * D + 0.03 * P)
            self.terms.append((0.5 * E, 0.03 * B1, 4 * D, 0.03 * P))
        else:
            Es, Bs, Ls, lam, mu = self.scales["E"], self.scales["B"], self.scales["L"], self.scales["lam"], self.scales["mu"]
            L = D                                            # availability loss: kappa_P * P_hat + kappa_E * E_hat
            te, tb, tl = E / Es, lam * B1 / Bs, mu * L / Ls
            r = -(te + tb + tl); self.terms.append((te, tb, tl))
        self.Es.append(E); self.Ds.append(D); self.ret += r; self.patched += P
        self.Pprev = P; self.t += 1
        if self.t < H_DAYS: self._begin_day()
        return r, self.t >= H_DAYS

    def metrics(self):
        N = len(self.c); rem = [i for i in range(N) if self.done[i] >= 0]
        dl = [(self.done[i] - self.arr[i] + 1) if self.done[i] >= 0 else (H_DAYS - self.arr[i]) for i in range(N)]
        return {"exposure_index": float(sum(self.Es)), "restricted_mean_delay": float(np.mean(dl)),
                "median_remediated_delay": float(np.median([self.done[i] - self.arr[i] + 1 for i in rem])) if rem else float("nan"),
                "unresolved_fraction": 1 - len(rem) / N, "availability_loss": float(sum(self.Ds)),
                "return": float(self.ret), "arrivals": N, "patched": self.patched, "constraint_violations": 0}

    # ---- observation (96 features) ---------------------------------------------------------------
    def observe(self):
        o = []
        for k in range(3):
            qk = self.queues[k]
            o += [len(qk) / 20.0, sum(min(1.0, self.h * self.p[i]) * self.w[i] for i in qk) / 5.0]
            for j in range(4):
                if j < len(qk):
                    i = qk[j]; cv = self.sev[i]
                    o += [min(1.0, self.h * self.p[i]) * self.w[i], cv / 10.0, min(1.0, self.h * self.p[i]),
                          float(self.kevf[i]), float(self.miss[i]), (self.t - self.arr[i]) / 15.0, 1.0]
                else:
                    o += [0.0] * 7
        o += [self.A, self.cap / CMAX, self.t / H_DAYS, np.sin(2 * np.pi * self.t / 7), np.cos(2 * np.pi * self.t / 7), 1.0]
        return np.array(o, dtype=np.float64)


# ---- SD prior: a pure function of the observation ------------------------------------------------
def sd_cost(obs, mask, mode="original", scales=None, h_scale=1.0, w_scale=1.0, horizon=5):
    """Cost J(a) of each action: horizon days of holding cost on the post-action state plus action costs.
    Reads only the observation. h_scale / w_scale implement prior misspecification (E2A)."""
    q = obs[:90].reshape(3, 30)
    lens = np.round(q[:, 0] * 20).astype(int)
    tot = q[:, 1] * 5.0
    items = q[:, 2:].reshape(3, 4, 7)
    wexp = items[:, :, 0]; thr = items[:, :, 2]
    w = np.where(thr > 0, wexp / np.maximum(thr, 1e-12), 0.0)
    wexp_m = np.minimum(1.0, thr * h_scale) * w * w_scale             # prior's own threat and weight assumptions
    if h_scale != 1.0 or w_scale != 1.0:             # queue totals rescaled by the heads' ratio (only heads are observed)
        hs = wexp.sum(1); tot = np.where(hs > 0, tot * wexp_m.sum(1) / np.maximum(hs, 1e-12), tot * w_scale)
    E = tot.sum(); B = lens.sum()
    cum = np.concatenate([np.zeros((3, 1)), np.cumsum(wexp_m, 1)], 1)    # exposure removed by patching n heads
    gain = cum[0, ACTIONS[:, 0]] + cum[1, ACTIONS[:, 1]] + cum[2, ACTIONS[:, 2]]
    n = ACTIONS.sum(1)
    E1 = np.maximum(E - gain, 0.0); B1 = B - n
    if mode == "original":
        D = B1C * n + B2C * E1
        J = horizon * (0.5 * E1 + 0.03 * B1) + 0.03 * n + 4 * D
    else:
        s = scales
        J = horizon * (E1 / s["E"] + s["lam"] * B1 / s["B"] + s["mu"] * B2C * E1 / s["L"]) + s["mu"] * horizon * B1C * n / s["L"]
    return np.where(mask, J, np.inf)


def sd_logits(obs, mask, **kw):
    J = sd_cost(obs, mask, **kw)
    f = np.isfinite(J)
    z = np.full(NA, -1e9)
    if f.sum() <= 1:
        z[f] = 0.0; return z
    sd = J[f].std()
    z[f] = 0.0 if sd == 0 else -(J[f] - J[f].mean()) / sd
    return z


# ---- rule-based policies -----------------------------------------------------------------------------
def _greedy_queue(ep, key):
    """Fill capacity one patch at a time from the queue whose head scores highest (FIFO within queues)."""
    heads = [0, 0, 0]; alloc = [0, 0, 0]
    for _ in range(ep.cap):
        cands = [(key(ep, ep.queues[k][heads[k]], k), -k, k) for k in range(3) if heads[k] < len(ep.queues[k])]
        if not cands: break
        k = max(cands)[2]; alloc[k] += 1; heads[k] += 1
    return int(np.flatnonzero((ACTIONS == alloc).all(1))[0])

def cvss_first(ep):  return _greedy_queue(ep, lambda e, i, k: -k)
def epss_first(ep):  return _greedy_queue(ep, lambda e, i, k: min(1.0, e.h * e.p[i]))
def kev_first(ep):   return _greedy_queue(ep, lambda e, i, k: (float(e.kevf[i]), min(1.0, e.h * e.p[i])))
def sd_only(ep, **kw):
    J = sd_cost(ep.observe(), ep.mask(), **kw)
    return int(np.argmin(J))
