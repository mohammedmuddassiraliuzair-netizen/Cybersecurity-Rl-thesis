# Reinforcement-learning study — thesis "Reinforcement Learning and Agentic AI in Cybersecurity Trade-off Analysis"

Implements the study of Chapters III–VI: revised reward, placebo-prior ablation (E1), prior-mismatch tests (E2) and
training-budget ladder (E3). Pre-registered in the WP0 specification.

## Reproduce and verify (what a reviewer should run)
Requirements: an x86-64 computer with AVX2 (any Intel or AMD CPU since about 2013), Linux, macOS (Intel) or
Windows, and either Docker or Python 3.12 with the pinned packages below.

With Docker (recommended; reproduces the exact software stack):
    docker build --platform linux/amd64 -t thesis-rl .
    docker run --rm --platform linux/amd64 thesis-rl bash -c "OUT=results_rerun ./run_all.sh && python3 verify_rl.py results_rerun"

Without Docker:
    pip install numpy==2.5.3 scipy==1.18.1 pandas==3.0.5 matplotlib==3.11.2
    python3 -m unittest discover -s tests -v      # 10 checks, about 3 seconds
    OUT=results_rerun ./run_all.sh                  # every experiment, about 1 hour on one CPU core
    python3 verify_rl.py results_rerun             # compares every result file with results/ byte for byte

`verify_rl.py` prints PASS when every CSV, JSON and checkpoint of the rerun is byte-for-byte identical to
the reference results in results/ and results_balanced/, from which every number in the thesis is taken.
run_all.sh pins the math libraries to the AVX2 code path (OPENBLAS_CORETYPE=Haswell, NumPy AVX-512 dispatch
disabled) and runs single-threaded; this is what makes results identical across x86-64 computers.
On Apple Silicon (ARM) computers floating-point results can differ in the last bits; use the Docker command
above, which runs the x86-64 image. Running ./run_all.sh without OUT never overwrites results/: completed
stages are skipped.

## Contents
- `hybrid_vm/env.py` environment, observation, SD prior, rule-based policies
- `hybrid_vm/ppo.py` NumPy PPO (96-32-35 actor, 96-32-1 critic), analytic gradients
- `run_study.py` reference scales, Twin-Testing + E1, E2, E3 (resumable; skips completed stages)
- `verify_rl.py` byte-for-byte comparison of a rerun with the reference results
- `Dockerfile` the exact software stack (Ubuntu 24.04, Python 3.12, pinned libraries)
- `analysis.py` H1, H2-threat, H2-asset, H3 with Holm; bootstrap intervals; effect sizes; Figures A-D
- `panel.npz` preserved 106-day as-of panel (SHA-256 in the original frozen protocol)
- `results/` all outputs: twin/ (checkpoints, manifest, integrity), e2.csv, e3_*, figures/, confirmatory_tests.json

