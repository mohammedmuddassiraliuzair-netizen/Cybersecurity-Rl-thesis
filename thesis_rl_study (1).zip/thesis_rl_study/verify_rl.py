"""Compare a rerun with the reference results used in the thesis.
Usage:  OUT=results_rerun ./run_all.sh   (about 1 hour)   then   python3 verify_rl.py results_rerun
Every result file (CSV, JSON, checkpoints) must be byte-for-byte identical to the reference in results/."""
import hashlib, os, sys
ROOT = os.path.dirname(os.path.abspath(__file__)); new = sys.argv[1] if len(sys.argv) > 1 else "results_rerun"
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
checked = mismatch = missing = 0
for ref_dir, new_dir in (("results", new), ("results_balanced", new + "_balanced")):
    for dp, _, files in os.walk(os.path.join(ROOT, ref_dir)):
        for f in files:
            if not f.endswith((".csv", ".json", ".npz")) or f == "e3_log.txt": continue
            a = os.path.join(dp, f); b = os.path.join(ROOT, new_dir, os.path.relpath(a, os.path.join(ROOT, ref_dir)))
            checked += 1
            if not os.path.exists(b): missing += 1; print("MISSING", os.path.relpath(b, ROOT))
            elif sha(a) != sha(b): mismatch += 1; print("DIFFERS", os.path.relpath(a, ROOT))
print(f"checked {checked} result files: {checked - mismatch - missing} identical, {mismatch} different, {missing} missing")
print("PASS: the rerun reproduces every reference result exactly." if checked and not (mismatch or missing) else "FAIL")
sys.exit(0 if checked and not (mismatch or missing) else 1)
