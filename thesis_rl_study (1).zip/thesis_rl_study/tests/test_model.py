"""Automated checks required before any reported run (specification Section 8)."""
import os, sys, unittest
import numpy as np, pandas as pd
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT)
from hybrid_vm.env import (Panel, Episode, CONDITIONS, H_DAYS, ACTIONS, NA, AMIN, sd_cost, sd_logits,
                           cvss_first, epss_first, kev_first)
from hybrid_vm.ppo import Agent
import run_study as RS

P = Panel(os.path.join(ROOT, "panel.npz")); S = RS.load_scales()


def roll(policy, seed=4000, start=90, cond="normal", mode="revised", **kw):
    ep = Episode(P, seed, start, cond, mode, S, **kw)
    while ep.t < H_DAYS: ep.step(policy(ep))
    return ep


class Structure(unittest.TestCase):
    def test_01_conservation(self):
        for s in range(4000, 4010):
            ep = roll(cvss_first, s)
            self.assertEqual(len(ep.c), ep.patched + len(ep._open()))          # B_end = arrivals - patches

    def test_02_bounds_and_feasibility(self):
        for cond in CONDITIONS:
            ep = Episode(P, 4001, 90, cond, "revised", S)
            while ep.t < H_DAYS:
                self.assertTrue(AMIN - 1e-12 <= ep.A <= 1 + 1e-12)
                m = ep.mask(); self.assertTrue(m[0]); self.assertTrue((ACTIONS[m].sum(1) <= ep.cap).all())
                ep.step(int(np.flatnonzero(m)[-1]))

    def test_03_infeasible_action_rejected(self):
        ep = Episode(P, 4002, 90, "normal", "revised", S)
        bad = np.flatnonzero(~ep.mask())
        if len(bad): self.assertRaises(ValueError, ep.step, int(bad[0]))

    def test_04_extreme_zero_capacity(self):
        ep = Episode(P, 4003, 90, "normal", "revised", S)
        while ep.t < H_DAYS: ep.step(0)                                           # never patch
        self.assertEqual(len(ep._open()), len(ep.c))                              # backlog = B0 + all arrivals

    def test_05_capacity_at_floor(self):
        ep = Episode(P, 4004, 90, "normal", "revised", S); ep.A = AMIN; B = len(ep._open())
        f = min(0.25, ep.h * B / (B + 30)); self.assertEqual(int(np.floor(4 * AMIN * (1 - f))), min(4, int(np.floor(4 * AMIN * ep.r * (1 - f)))))

    def test_06_feedback_sign(self):
        """Lower availability gives lower capacity, other things equal."""
        ep = Episode(P, 4005, 90, "normal", "revised", S); B = len(ep._open()); f = min(0.25, B / (B + 30))
        caps = [min(4, int(np.floor(4 * a * (1 - f)))) for a in (1.0, 0.8, 0.6)]
        self.assertTrue(caps[0] >= caps[1] >= caps[2] and caps[0] > caps[2])

    def test_07_reward_decomposition(self):
        ep = Episode(P, 4006, 90, "normal", "revised", S); rs = []
        while ep.t < H_DAYS: r, _ = ep.step(cvss_first(ep)); rs.append(r)
        for r, terms in zip(rs, ep.terms): self.assertAlmostEqual(-sum(terms), r, places=12)
        # positive rescaling of -(0.5E + 0.03B + 4L)
        for (te, tb, tl), E, D in zip(ep.terms, ep.Es, ep.Ds):
            self.assertAlmostEqual(te * 0.5 * S["E"], 0.5 * E, places=10); self.assertAlmostEqual(tl * 0.5 * S["E"], 4 * D, places=10)

    def test_08_prior_identities(self):
        ep = Episode(P, 4007, 90, "normal", "revised", S)
        while ep.t < H_DAYS:
            o, m = ep.observe(), ep.mask(); z = sd_logits(o, m, mode="revised", scales=S)
            self.assertEqual(int(np.argmax(z)), int(np.argmin(sd_cost(o, m, mode="revised", scales=S))))
            self.assertTrue(np.all(z[~m] < -1e8)); ep.step(int(np.argmax(z)))
        ag = Agent("M2P", 1); X = np.random.default_rng(0).normal(size=(5, 96)); M = np.ones((5, NA), bool)
        z1, _, _ = ag.logits(X, np.zeros((5, NA)), M); z2, _, _ = ag.logits(X, np.full((5, NA), 9.0), M)
        self.assertTrue(np.allclose(z1, z2))                                      # placebo ignores the prior
        self.assertTrue(np.all(np.abs(z1) <= 2))                                   # residual bound

    def test_09_no_lookahead(self):
        ep = Episode(P, 4008, 90, "normal", "revised", S)
        while ep.t < H_DAYS:
            d = ep._day(ep.t)
            for i in ep._open():                                                   # nothing published after day d
                self.assertLessEqual(P.pub[ep.c[i]], d)
            ep.step(cvss_first(ep))
        self.assertTrue(max(RS.TRAIN_STARTS) + H_DAYS - 1 < RS.VAL_START <= RS.VAL_START + H_DAYS - 1 < RS.TEST_START)

    def test_10_determinism(self):
        a, b = roll(epss_first, 4009).metrics(), roll(epss_first, 4009).metrics()
        self.assertEqual(a, b)
        _, l1, _ = RS.train("M2", 11, S, updates=2); _, l2, _ = RS.train("M2", 11, S, updates=2)
        self.assertEqual(l1, l2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
