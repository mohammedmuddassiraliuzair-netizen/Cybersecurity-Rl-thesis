"""Run the pre-registered study (specification v1.0, WP0). Usage:
    python run_study.py scales | twin | e2 | e3 | all
Results go to results/; the runner refuses to overwrite a completed stage.
"""
import json, os, sys, time, hashlib
import numpy as np, pandas as pd
from hybrid_vm.env import (Panel, Episode, CONDITIONS, H_DAYS, ACTIONS, sd_cost, sd_logits,
                           cvss_first, epss_first, kev_first)
from hybrid_vm.ppo import Agent, gae

ROOT = os.path.dirname(os.path.abspath(__file__))
VARIANT = os.environ.get("VARIANT", "")              # "" = pre-registered study; "balanced" = exploratory (lambda = mu = 1)
OUT = os.environ.get("OUT", "results")              # output folder; verify_rl.py compares a rerun folder with "results"
RES = os.path.join(ROOT, OUT if not VARIANT else f"{OUT}_{VARIANT}"); os.makedirs(RES, exist_ok=True)
PANEL = Panel(os.path.join(ROOT, "panel.npz"))
SEEDS = [11, 23, 37, 53, 71, 89, 107, 127, 149, 173, 197, 223, 251, 281, 313, 347, 383, 421, 461, 503,
         547, 593, 641, 691, 743, 797, 853, 911, 971, 1033]                       # fixed training seeds
TEST_START, TEST_TRACES = 90, list(range(4000, 4030))
VAL_START, VAL_TRACES = 45, list(range(2000, 2030))
TRAIN_STARTS = (0, 30)
UPDATES, EPISODES = 40, 16


def sha(path): return hashlib.sha256(open(path, "rb").read()).hexdigest()
def save_json(o, name): json.dump(o, open(os.path.join(RES, name), "w"), indent=1)


# ---- D3: reference scales from SD-only on the training partition ------------------------------------
def compute_scales():
    E, B, L = [], [], []
    for k in range(310):
        start, seed = k % 31, 1_000_000 + k
        ep = Episode(PANEL, seed, start, "normal", "original")
        while ep.t < H_DAYS:
            a = int(np.argmin(sd_cost(ep.observe(), ep.mask(), mode="original")))
            ep.step(a); E.append(ep.Es[-1]); L.append(ep.Ds[-1]); B.append(len(ep._open()))
    Es, Bs, Ls = (float(np.percentile(x, 99)) for x in (E, B, L))
    S = {"E": Es, "B": Bs, "L": Ls, "lam": 0.06 * Bs / Es, "mu": 8 * Ls / Es, "episodes": 310,
         "rule": "99th percentile of per-step E, B(t+1), L under SD-only (original cost), training starts 0-30"}
    save_json(S, "reference_scales.json"); return S

def load_scales():
    S = json.load(open(os.path.join(ROOT, OUT, "reference_scales.json")))     # same reference scales (D3)
    if VARIANT == "balanced": S = dict(S, lam=1.0, mu=1.0, rule=S["rule"] + "; EXPLORATORY: lambda = mu = 1")
    return S


# ---- policies ------------------------------------------------------------------------------------------
def prior(ep, S, h_scale=1.0, w_scale=1.0):
    return sd_logits(ep.observe(), ep.mask(), mode="revised", scales=S, h_scale=h_scale, w_scale=w_scale)

def make_policy(name, S, agent=None, h_scale=1.0, w_scale=1.0):
    if name == "B1": return cvss_first
    if name == "B2": return epss_first
    if name == "B3": return kev_first
    if name == "B4": return lambda ep: int(np.argmax(prior(ep, S, h_scale, w_scale)))
    def f(ep):
        o, m = ep.observe(), ep.mask()
        z = sd_logits(o, m, mode="revised", scales=S, h_scale=h_scale, w_scale=w_scale) if agent.arm == "M2" else np.zeros(len(ACTIONS))
        return agent.act(o, z, m)
    return f

def evaluate(policy, S, start, traces, condition="normal", h_env=None, w_env=1.0, resid_agent=None):
    rows = []
    for s in traces:
        ep = Episode(PANEL, s, start, condition, "revised", S, h_env=h_env, w_scale_env=w_env); Rm = []
        while ep.t < H_DAYS:
            if resid_agent is not None and resid_agent.arm in ("M2", "M2P"):
                o, m = ep.observe(), ep.mask()
                z = sd_logits(o, m, mode="revised", scales=S) if resid_agent.arm == "M2" else np.zeros(len(ACTIONS))
                if m.sum() > 1: Rm.append(resid_agent.residual_magnitude(o, z, m))
            ep.step(policy(ep))
        r = ep.metrics(); r["trace_seed"] = s; r["residual_magnitude"] = float(np.mean(Rm)) if Rm else np.nan
        rows.append(r)
    return rows


# ---- training ----------------------------------------------------------------------------------------------
def train(arm, seed, S, updates=UPDATES, val_every=None):
    ag = Agent(arm, seed)
    rtr = np.random.default_rng([seed, 1]); rpol = np.random.default_rng([seed, 2]); rupd = np.random.default_rng([seed, 3])
    log, curve = [], []
    for u in range(1, updates + 1):
        Bt = {k: [] for k in ("obs", "zsd", "mask", "act", "logp", "adv", "ret")}; rets = []
        for _ in range(EPISODES):
            start = int(rtr.integers(TRAIN_STARTS[0], TRAIN_STARTS[1] + 1)); tseed = int(rtr.integers(0, 2**31 - 1))
            ep = Episode(PANEL, tseed, start, "normal", "revised", S); O, Z, M, A, LP, R, V = [], [], [], [], [], [], []
            while ep.t < H_DAYS:
                o, m = ep.observe(), ep.mask()
                z = sd_logits(o, m, mode="revised", scales=S) if arm == "M2" else np.zeros(len(ACTIONS))
                a, lp = ag.act(o, z, m, rpol); v, _ = ag.value(o[None])
                r, _ = ep.step(a); O.append(o); Z.append(z); M.append(m); A.append(a); LP.append(lp); R.append(r); V.append(float(v[0]))
            adv, ret = gae(np.array(R), V); rets.append(sum(R))
            for k, x in zip(("obs", "zsd", "mask", "act", "logp", "adv", "ret"), (O, Z, M, A, LP, adv, ret)): Bt[k] += list(x)
        Bt = {k: np.array(v) for k, v in Bt.items()}
        st = ag.update(Bt, rupd); log.append({"update": u, "mean_return": float(np.mean(rets)), **st})
        if val_every and u % val_every == 0:
            pol = make_policy(arm, S, ag); rows = evaluate(pol, S, VAL_START, VAL_TRACES)
            curve.append({"update": u, "transitions": u * EPISODES * H_DAYS, "val_exposure": float(np.mean([r["exposure_index"] for r in rows]))})
    return ag, log, curve


# ---- stages ------------------------------------------------------------------------------------------------
def stage_twin(S):
    out = os.path.join(RES, "twin")
    if os.path.exists(os.path.join(out, "test_results.csv")): print("twin: already complete, skipping"); return
    os.makedirs(out, exist_ok=True); os.makedirs(os.path.join(out, "logs"), exist_ok=True); t0 = time.time(); agents = {}; logs = []
    for arm in ("M1", "M2P", "M2"):
        for s in SEEDS:
            ck, lg = os.path.join(out, f"{arm}_seed{s}.npz"), os.path.join(out, "logs", f"{arm}_seed{s}.csv")
            if os.path.exists(ck) and os.path.exists(lg):                     # resumable: reuse a finished agent
                ag = load_agent(arm, s, out); log = pd.read_csv(lg, float_precision="round_trip").to_dict("records")
            else:
                ag, log, _ = train(arm, s, S); np.savez(ck, **ag.params())
                pd.DataFrame([{"arm": arm, "seed": s, **r} for r in log]).to_csv(lg, index=False)
                print(f"trained {arm} seed {s} final return {log[-1]['mean_return']:.3f}", flush=True)
            agents[(arm, s)] = ag; logs += [{"arm": arm, "seed": s, **{k: v for k, v in r.items() if k not in ("arm", "seed")}} for r in log]
    pd.DataFrame(logs).to_csv(os.path.join(out, "training_log.csv"), index=False)
    manifest = {f: sha(os.path.join(out, f)) for f in sorted(os.listdir(out)) if f.endswith(".npz")}
    pd.DataFrame(logs).to_csv(os.path.join(out, "training_log.csv"), index=False)
    save_json(manifest, "twin/checkpoint_manifest_before_test.json")
    rows = []                                                                   # test opened only now
    for cond in CONDITIONS:
        for b in ("B1", "B2", "B3", "B4"):
            for r in evaluate(make_policy(b, S), S, TEST_START, TEST_TRACES, cond): rows.append({"arm": b, "seed": -1, "condition": cond, **r})
        for (arm, s), ag in agents.items():
            for r in evaluate(make_policy(arm, S, ag), S, TEST_START, TEST_TRACES, cond, resid_agent=ag):
                rows.append({"arm": arm, "seed": s, "condition": cond, **r})
        print("evaluated", cond, flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(out, "test_results.csv"), index=False)
    after = {f: sha(os.path.join(out, f)) for f in manifest}
    save_json({"checkpoint_hashes_unchanged": after == manifest}, "twin/integrity.json")


def load_agent(arm, s, folder=None):
    ag = Agent(arm, s); z = np.load(os.path.join(folder or os.path.join(RES, "twin"), f"{arm}_seed{s}.npz"))
    ag.actor = [z[f"actor_{i}"] for i in range(4)]; ag.critic = [z[f"critic_{i}"] for i in range(4)]; return ag

def stage_e2(S):
    out = os.path.join(RES, "e2.csv")
    if os.path.exists(out): print("e2: already complete, skipping"); return
    deltas = [-0.3, -0.2, -0.1, 0.0, 0.1, 0.2, 0.3]; allrows = []; seeds = SEEDS[:15]; part = os.path.join(RES, "e2_parts"); os.makedirs(part, exist_ok=True)
    for param in ("threat", "asset"):
        for d in deltas:
            fp = os.path.join(part, f"{param}_{d:+.1f}.csv")
            if os.path.exists(fp): allrows.append(pd.read_csv(fp, float_precision="round_trip")); continue
            rows = []
            hs, ws = (1 + d, 1.0) if param == "threat" else (1.0, 1 + d)
            # E2A: wrong prior, correct environment
            for r in evaluate(make_policy("B4", S, h_scale=hs, w_scale=ws), S, TEST_START, TEST_TRACES):
                rows.append({"exp": "E2A", "param": param, "delta": d, "arm": "B4", "seed": -1, **r})
            for s in seeds:
                ag = load_agent("M2", s)
                for r in evaluate(make_policy("M2", S, ag, hs, ws), S, TEST_START, TEST_TRACES):
                    rows.append({"exp": "E2A", "param": param, "delta": d, "arm": "M2", "seed": s, **r})
            # E2B: shifted environment, prior frozen at nominal (prior undoes the shift seen in observations)
            he, we = (1 + d, 1.0) if param == "threat" else (1.0, 1 + d)
            for arm in ("B4", "M1", "M2"):
                for s in ([-1] if arm == "B4" else seeds):
                    ag = None if arm == "B4" else load_agent(arm, s)
                    pol = make_policy(arm, S, ag, 1 / he, 1 / we)
                    for r in evaluate(pol, S, TEST_START, TEST_TRACES, h_env=he, w_env=we):
                        rows.append({"exp": "E2B", "param": param, "delta": d, "arm": arm, "seed": s, **r})
            pd.DataFrame(rows).to_csv(fp, index=False); allrows.append(pd.read_csv(fp, float_precision="round_trip")); print("e2", param, d, flush=True)
    pd.concat(allrows).to_csv(out, index=False)


def stage_e3(S):
    out = os.path.join(RES, "e3_curves.csv")
    if os.path.exists(out): print("e3: already complete, skipping"); return
    rows, check = [], []; part = os.path.join(RES, "e3_parts"); os.makedirs(part, exist_ok=True)
    for arm in ("M1", "M2"):
        for s in SEEDS[:15]:
            f = os.path.join(part, f"{arm}_seed{s}.csv")
            if not os.path.exists(f):                                    # resumable: each finished run is saved
                ag, log, curve = train(arm, s, S, updates=400, val_every=20)
                pd.DataFrame([{"arm": arm, "seed": s, **c} for c in curve]).to_csv(f, index=False)
                print(f"e3 {arm} seed {s} final val {curve[-1]['val_exposure']:.3f}", flush=True)
            rows.append(pd.read_csv(f, float_precision="round_trip"))
    pd.concat(rows).to_csv(out, index=False)
    for b in ("B1", "B4"):
        v = evaluate(make_policy(b, S), S, VAL_START, VAL_TRACES)
        check.append({"arm": b, "val_exposure": float(np.mean([r["exposure_index"] for r in v]))})
    pd.DataFrame(check).to_csv(os.path.join(RES, "e3_reference_lines.csv"), index=False)


if __name__ == "__main__":
    stage = sys.argv[1] if len(sys.argv) > 1 else "all"
    S = compute_scales() if (stage in ("scales", "all") and not VARIANT) else load_scales()
    if VARIANT: save_json(S, "reference_scales.json")
    print("scales", S, flush=True)
    if stage in ("twin", "all"): stage_twin(S)
    if stage in ("e2", "all"): stage_e2(S)
    if stage in ("e3", "all"): stage_e3(S)
