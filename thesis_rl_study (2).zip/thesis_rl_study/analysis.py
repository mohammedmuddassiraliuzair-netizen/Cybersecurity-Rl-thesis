"""Pre-registered analysis (specification Sections 3 and 7): H1, H2-threat, H2-asset, H3 with Holm
correction; paired rank-biserial effects; bootstrap 95% intervals (10,000 resamples); IQM with
bootstrap intervals; Table XVII; Twin-Testing summary; Figures A-D and the Twin-Testing figure."""
import os, json
import numpy as np, pandas as pd
from scipy.stats import wilcoxon
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.abspath(__file__)); RES = os.path.join(ROOT, os.environ.get("OUT", "results")); FIG = os.path.join(RES, "figures")
os.makedirs(FIG, exist_ok=True)
RNG = np.random.default_rng(20261007); NB = 10_000
NAMES = {"B1": "CVSS-First (B1)", "B2": "EPSS-First (B2)", "B3": "KEV-First (B3)", "B4": "SD-Only (B4)",
         "M1": "Model-Free PPO (M1)", "M2P": "Placebo Residual (M2-P)", "M2": "Residual PPO (M2)"}
plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 9.5, "axes.labelsize": 9.5, "xtick.labelsize": 9, "ytick.labelsize": 9, "legend.fontsize": 8.5, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": False, "hatch.linewidth": 0.5, "grid.color": "#d8dee4", "grid.linewidth": 0.6, "legend.frameon": False,
                     "figure.dpi": 300, "savefig.bbox": "tight"})
COL = {"B1": "#000000", "B2": "#ffffff", "B3": "#ffffff", "B4": "#ffffff", "M1": "#ffffff", "M2P": "#ffffff", "M2": "#ffffff"}   # strictly black and white
HATCH = {"B1": "", "B2": "////", "B3": "\\\\\\\\", "B4": "", "M1": "xxx", "M2P": "...", "M2": "---"}
MK = {"B1": "D", "B4": "o", "M1": "s", "M2": "^"}

def boot_mean(x, n=NB):
    x = np.asarray(x, float); b = RNG.choice(x, (n, len(x))).mean(1); return float(np.percentile(b, 2.5)), float(np.percentile(b, 97.5))

def iqm(x):
    x = np.sort(np.asarray(x, float)); k = len(x); lo, hi = int(np.floor(0.25 * k)), int(np.ceil(0.75 * k)); return float(x[lo:hi].mean())

def boot_iqm(x, n=NB):
    x = np.asarray(x, float); b = [iqm(RNG.choice(x, len(x))) for _ in range(n)]; return float(np.percentile(b, 2.5)), float(np.percentile(b, 97.5))

def rank_biserial(d):
    """Paired rank-biserial correlation for differences d (negative = first arm lower exposure)."""
    d = np.asarray(d, float); d = d[d != 0]
    if len(d) == 0: return 0.0
    r = pd.Series(np.abs(d)).rank().values; wp, wm = r[d > 0].sum(), r[d < 0].sum(); return float((wp - wm) / (wp + wm))

def holm(p):
    p = np.asarray(p, float); m = len(p); o = np.argsort(p); adj = np.empty(m); run = 0.0
    for i, j in enumerate(o): run = max(run, min(1.0, (m - i) * p[j])); adj[j] = run
    return adj


def main():
    out = {}
    T = pd.read_csv(os.path.join(RES, "twin", "test_results.csv"))
    seed_means = T.groupby(["condition", "arm", "seed"], as_index=False).mean(numeric_only=True)

    # ---- Twin-Testing summary ---------------------------------------------------------------------------------
    rows = []
    for (c, a), g in seed_means.groupby(["condition", "arm"]):
        x = g.exposure_index.values; lo, hi = boot_mean(x) if len(x) > 1 else boot_mean(T[(T.condition == c) & (T.arm == a)].exposure_index.values)
        rows.append({"condition": c, "arm": a, "exposure": x.mean(), "exp_lo": lo, "exp_hi": hi,
                     "delay": g.restricted_mean_delay.mean(), "unresolved": g.unresolved_fraction.mean(),
                     "availability_loss": g.availability_loss.mean(), "iqm_exposure": iqm(x) if len(x) > 1 else x.mean()})
    S = pd.DataFrame(rows); S.to_csv(os.path.join(RES, "twin_summary.csv"), index=False)

    # ---- E1 / H1 and Table XVII ---------------------------------------------------------------------------------
    nom = seed_means[seed_means.condition == "normal"]
    J = {a: nom[nom.arm == a].set_index("seed").exposure_index for a in ("M1", "M2P", "M2")}
    Jb4 = float(nom[nom.arm == "B4"].exposure_index.iloc[0])
    d_h1 = (J["M2"] - J["M2P"]).values
    p_h1 = wilcoxon(d_h1, alternative="less").pvalue
    tab17 = []
    for a in ("M1", "M2P", "B4", "M2"):
        if a == "B4":
            e = Jb4; dl = float(nom[nom.arm == "B4"].restricted_mean_delay.iloc[0]); rm = np.nan; eff = Jb4 - J["M2"].mean()
        else:
            g = nom[nom.arm == a]; e = g.exposure_index.mean(); dl = g.restricted_mean_delay.mean(); rm = g.residual_magnitude.mean()
            eff = (J[a] - J["M2"]).mean() if a != "M2" else 0.0
        tab17.append({"arm": a, "exposure": e, "delay": dl, "residual_magnitude": rm, "effect_vs_M2_exposure": eff})
    pd.DataFrame(tab17).to_csv(os.path.join(RES, "table_XVII_ablation.csv"), index=False)

    # ---- E2 / H2 -------------------------------------------------------------------------------------------------------
    E2 = pd.read_csv(os.path.join(RES, "e2.csv"))
    e2m = E2.groupby(["exp", "param", "delta", "arm", "seed"], as_index=False).exposure_index.mean()
    h2 = {}; rr_rows = []
    for param in ("threat", "asset"):
        a = e2m[(e2m.exp == "E2A") & (e2m.param == param)]
        b4 = a[a.arm == "B4"].set_index("delta").exposure_index
        mp_b4 = np.mean([(b4[d] - b4[0.0]) / b4[0.0] for d in b4.index if d != 0.0])
        m2 = a[a.arm == "M2"].pivot(index="seed", columns="delta", values="exposure_index")
        mp_m2 = np.mean([(m2[d] - m2[0.0]) / m2[0.0] for d in m2.columns if d != 0.0], axis=0)
        diff = mp_m2 - mp_b4
        h2[param] = {"p": wilcoxon(diff, alternative="less").pvalue, "median_diff": float(np.median(diff)),
                     "ci": boot_mean(diff), "rank_biserial": rank_biserial(diff), "mp_b4": float(mp_b4),
                     "mp_m2_mean": float(np.mean(mp_m2))}
        for d in sorted(b4.index):
            rr = (b4[d] - m2[d]) / b4[d]; rr_rows.append({"param": param, "delta": d, "RR_mean": rr.mean(), "RR_lo": boot_mean(rr)[0], "RR_hi": boot_mean(rr)[1]})
    pd.DataFrame(rr_rows).to_csv(os.path.join(RES, "e2_repair_ratio.csv"), index=False)
    e2_summary = e2m.groupby(["exp", "param", "delta", "arm"], as_index=False).exposure_index.mean()
    e2_summary.to_csv(os.path.join(RES, "e2_summary.csv"), index=False)

    # ---- E3 / H3 -------------------------------------------------------------------------------------------------------
    C = pd.read_csv(os.path.join(RES, "e3_curves.csv")); ref = pd.read_csv(os.path.join(RES, "e3_reference_lines.csv")).set_index("arm").val_exposure
    def aulc(g):
        g = g.sort_values("transitions"); x, y = g.transitions.values, g.val_exposure.values
        return float(np.trapezoid(y, x) / (x[-1] - x[0])) if hasattr(np, "trapezoid") else float(np.trapz(y, x) / (x[-1] - x[0]))
    au = C.groupby(["arm", "seed"]).apply(aulc, include_groups=False).unstack(0)
    d_h3 = (au["M2"] - au["M1"]).values; p_h3 = wilcoxon(d_h3, alternative="less").pvalue
    curve = C.groupby(["arm", "transitions"], as_index=False).val_exposure.mean()
    conv = {}
    for a in ("M1", "M2"):
        g = curve[curve.arm == a].set_index("transitions").val_exposure; k = g.index.values
        last, at80 = g.loc[k.max()], g.loc[k[np.argmin(np.abs(k - 0.8 * k.max()))]]
        conv[a] = {"C_final_20pct": float(abs(last - at80) / at80), "converged": bool(abs(last - at80) / at80 < 0.01)}
    ladder = curve[curve.transitions.isin([9600, 24000, 48000, 96000])].pivot(index="transitions", columns="arm", values="val_exposure")
    ladder.to_csv(os.path.join(RES, "e3_ladder.csv"))

    # ---- Holm family ---------------------------------------------------------------------------------------------------
    fam = {"H1": p_h1, "H2-threat": h2["threat"]["p"], "H2-asset": h2["asset"]["p"], "H3": p_h3}
    adj = dict(zip(fam, holm(list(fam.values()))))
    tests = {"H1": {"claim": "J(M2) < J(M2-P), nominal", "p": p_h1, "p_holm": adj["H1"], "median_diff": float(np.median(d_h1)),
                    "ci_mean_diff": boot_mean(d_h1), "rank_biserial": rank_biserial(d_h1), "n": len(d_h1)},
             "H2-threat": {"claim": "mismatch penalty M2 < B4 (threat)", "p_holm": adj["H2-threat"], **h2["threat"], "n": 15},
             "H2-asset": {"claim": "mismatch penalty M2 < B4 (asset)", "p_holm": adj["H2-asset"], **h2["asset"], "n": 15},
             "H3": {"claim": "AULC(M2) < AULC(M1)", "p": p_h3, "p_holm": adj["H3"], "median_diff": float(np.median(d_h3)),
                    "ci_mean_diff": boot_mean(d_h3), "rank_biserial": rank_biserial(d_h3), "n": len(d_h3),
                    "aulc_M1": float(au["M1"].mean()), "aulc_M2": float(au["M2"].mean())}}
    iq = {a: {"iqm": iqm(J[a].values), "ci": boot_iqm(J[a].values)} for a in J}
    json.dump({"tests": tests, "iqm_nominal": iq, "convergence": conv, "B4_nominal": Jb4,
               "reference_lines_validation": ref.to_dict()}, open(os.path.join(RES, "confirmatory_tests.json"), "w"), indent=1, default=float)

    # ---- Figures --------------------------------------------------------------------------------------------------------
    arms = ["B1", "B2", "B3", "B4", "M1", "M2P", "M2"]; conds = ["normal", "threat", "resource", "asset", "joint"]
    fig, ax = plt.subplots(figsize=(6.5, 4.4)); w = 0.11
    for i, a in enumerate(arms):
        s = S[S.arm == a].set_index("condition").reindex(conds)
        ax.bar(np.arange(5) + (i - 3) * w, s.exposure, w, yerr=[s.exposure - s.exp_lo, s.exp_hi - s.exposure], color=COL[a], hatch=HATCH[a], edgecolor="black", lw=0.5, label=NAMES[a], error_kw=dict(lw=0.6))
    ax.set_xticks(range(5)); ax.set_xticklabels(["Nominal", "Threat\n×2", "Capacity\n×0.6", "Asset weights\n×2", "Joint"])
    ax.set_ylabel("Cumulative exposure index (lower is better)"); ax.legend(ncol=3, fontsize=8.5, loc="upper center", bbox_to_anchor=(0.5, -0.1))
    fig.savefig(os.path.join(FIG, "twin_testing_exposure.png")); plt.close(fig)

    fig, ax = plt.subplots(figsize=(5.5, 3.8))
    for i, a in enumerate(["M1", "M2P", "B4", "M2"]):
        if a == "B4": ax.bar(i, Jb4, color=COL[a], hatch=HATCH[a], edgecolor="black", lw=0.6)
        else:
            x = J[a].values; lo, hi = boot_mean(x); ax.bar(i, x.mean(), yerr=[[x.mean() - lo], [hi - x.mean()]], color=COL[a], hatch=HATCH[a], edgecolor="black", lw=0.6, error_kw=dict(lw=0.8))
            ax.scatter(np.full(len(x), i) + RNG.uniform(-0.15, 0.15, len(x)), x, s=7, color="black", zorder=3)
    ax.set_xticks(range(4)); ax.set_xticklabels(["Model-Free\nPPO (M1)", "Placebo\nResidual\n(M2-P)", "SD-Only\n(B4)", "Residual\nPPO (M2)"], fontsize=9)
    ax.set_ylabel("Nominal cumulative exposure")
    fig.savefig(os.path.join(FIG, "figA_prior_ablation.png")); plt.close(fig)

    fig, axs = plt.subplots(2, 1, figsize=(6.5, 7.4), sharey=False)
    for axx, param in zip(axs, ("threat", "asset")):
        for exp, ls in (("E2A", "-"), ("E2B", "--")):
            for a in (("B4", "M2") if exp == "E2A" else ("B4", "M1", "M2")):
                s = e2_summary[(e2_summary.exp == exp) & (e2_summary.param == param) & (e2_summary.arm == a)].sort_values("delta")
                axx.plot(s.delta, s.exposure_index, ls, marker=MK[a], ms=4, mfc="white", color="black", label=f"{NAMES[a]}, {'wrong prior' if exp == 'E2A' else 'shifted environment'}")
        axx.set_xlabel(f"Mismatch δ ({'threat scaling' if param == 'threat' else 'asset weights'})"); axx.set_ylabel("Cumulative exposure")
    axs[1].legend(*axs[0].get_legend_handles_labels(), fontsize=8.5, loc="upper center", bbox_to_anchor=(0.5, -0.17), ncol=2)
    fig.savefig(os.path.join(FIG, "figB_mismatch.png")); plt.close(fig)

    R = pd.DataFrame(rr_rows); fig, ax = plt.subplots(figsize=(5.5, 3.5))
    for param, c, lsty, mk in (("threat", "black", "-", "o"), ("asset", "black", "--", "s")):
        s = R[R.param == param]; ax.plot(s.delta, s.RR_mean, marker=mk, ls=lsty, mfc="white", color=c, label=f"{param} mismatch")
        ax.plot(s.delta, s.RR_lo, ls=lsty, color="black", lw=0.6); ax.plot(s.delta, s.RR_hi, ls=lsty, color="black", lw=0.6)
    ax.axhline(0, color="black", lw=0.8); ax.set_xlabel("Prior mismatch δ"); ax.set_ylabel("Repair ratio RR(δ)")
    ax.legend(fontsize=9)
    fig.savefig(os.path.join(FIG, "figC_repair_ratio.png")); plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    for a in ("M1", "M2"):
        g = C[C.arm == a].groupby("transitions").val_exposure; m = g.mean(); sd = g.std()
        ax.plot(m.index, m.values, color="black", ls="--" if a == "M1" else "-", label=NAMES[a]); ax.plot(m.index, m - sd, color="black", lw=0.5, ls="--" if a == "M1" else "-"); ax.plot(m.index, m + sd, color="black", lw=0.5, ls="--" if a == "M1" else "-")
    ax.axhline(ref["B4"], color="black", ls="-.", lw=1, label=NAMES["B4"]); ax.axhline(ref["B1"], color="black", ls=":", lw=1.4, label=NAMES["B1"])
    ax.set_xscale("log"); ax.set_xlabel("Training transitions (log scale)"); ax.set_ylabel("Validation cumulative exposure")
    ax.legend(fontsize=8.5)
    fig.savefig(os.path.join(FIG, "figD_learning_curves.png")); plt.close(fig)
    print(json.dumps({"tests": tests, "convergence": conv}, indent=1, default=float))


if __name__ == "__main__":
    main()
